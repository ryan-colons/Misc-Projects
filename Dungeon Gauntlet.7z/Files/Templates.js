//TEMPLATES

var EnemyTemplate = {
	name: "enemy",
	type: "evil",
	allthestats: 0,
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};

var SpellTemplate = {
	name: "Abracadabra",
	use: ["combat", "shop"],
	description: "<br><strong>Abracadabra</strong><br><br><em>Woo magic!</em><br><br>zap<br>whoosh",
	effect: function(){ print("You do a magic.<br>") }
};

var ItemTemplate = {
	name: "item",
	type: "usable",
	use: ["combat"],
	value: 0.25,
	description: "<br><strong>Item</strong><br><br><em>Does a thing.</em><br><br>Usable only in combat.<br>Destroyed on use.",
	effect: function(){ print("A thing happens.<br>") }
};

var EquipmentTemplate = {
	name: "equipment",
	type: "equipment",
	slot: "head",
	restrictions: [],
	stats: {
		str: 1,
	},
	enchantable: false,
	EquipMessage: function(){ print("You put it on.<br>") },
	UnequipMessage: function(){ print("You take it off.<br>") },
	SlimeMessage: function(){ print("It dissolves.<br>") },
	On: function(){},
	Off: function(){},
	description: "<br><strong>Equipment</strong><br><br><em>A piece of equipment.</em><br><br>+1 str"
};

var BuffTemplate = {
	counter: 0,
	On: function(){},
	WhileOn: function(){},
	Off: function(){}
};

