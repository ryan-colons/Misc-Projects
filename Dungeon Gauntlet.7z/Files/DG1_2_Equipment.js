//Equipment
var EquipItem = function(itemid){
	if (Player.Race == R_Slime){
		AbsorbItem();
		return;
	};
	var item = window[itemid];
	var type = item.slot;
	//restrictions
	if (Equipped[type] != 0){
	    window.alert("You already have an item equipped in that slot. Unequip that first.");
		return;
	};
	item.EquipMessage();
	if (item.hasOwnProperty("On")) item.On();
	if (item.stats.hasOwnProperty('HP') == true) BoostExtrinsics("HP",item.stats.HP);
	if (item.stats.hasOwnProperty('armor') == true) BoostExtrinsics("armor",item.stats.armor);
	if (item.stats.hasOwnProperty('str') == true) BoostExtrinsics("str",item.stats.str);
	if (item.stats.hasOwnProperty('mag') == true) BoostExtrinsics("mag",item.stats.mag);
	if (item.stats.hasOwnProperty('acc') == true) BoostExtrinsics("acc",item.stats.acc);
	if (item.stats.hasOwnProperty('eva') == true) BoostExtrinsics("eva",item.stats.eva);
	if (item.stats.hasOwnProperty('luck') == true) BoostExtrinsics("luck",item.stats.luck);
	RefreshStatsPanel();

	Equipped[type] = itemid;
	var index = Inventory.equipment.indexOf(itemid);
	Inventory.equipment.splice(index,1);
	
	RefreshInventoryMenu();
	RefreshButtons();
};
var UnequipItem = function(itemid){
	var item = window[itemid];
	var type = item.slot;
	item.UnequipMessage();
	if (item.hasOwnProperty("Off")) item.Off();
	if (item.stats.hasOwnProperty('HP') == true) UnboostExtrinsics("HP",item.stats.HP);
	if (item.stats.hasOwnProperty('armor') == true) UnboostExtrinsics("armor",item.stats.armor);
	if (item.stats.hasOwnProperty('str') == true) UnboostExtrinsics("str",item.stats.str);
	if (item.stats.hasOwnProperty('mag') == true) UnboostExtrinsics("mag",item.stats.mag);
	if (item.stats.hasOwnProperty('acc') == true) UnboostExtrinsics("acc",item.stats.acc);
	if (item.stats.hasOwnProperty('eva') == true) UnboostExtrinsics("eva",item.stats.eva);
	if (item.stats.hasOwnProperty('luck') == true) UnboostExtrinsics("luck",item.stats.luck);
	
	Inventory.equipment.push(itemid);
	Equipped[type] = 0;
	
	RefreshStatsPanel();
	RefreshInventoryMenu();
	RefreshButtons();
};
var AbsorbItem = function(itemid){
	var item = window[itemid];
	item.SlimeMessage();
	if (item.hasOwnProperty("NoSlime") == true) return;
	if (item.stats.hasOwnProperty('HP') == true) BoostIntrinsics("HP",item.stats.HP);
	if (item.stats.hasOwnProperty('armor') == true) BoostIntrinsics("armor",item.stats.armor);
	if (item.stats.hasOwnProperty('str') == true) BoostIntrinsics("str",item.stats.str);
	if (item.stats.hasOwnProperty('mag') == true) BoostIntrinsics("mag",item.stats.mag);
	if (item.stats.hasOwnProperty('acc') == true) BoostIntrinsics("acc",item.stats.acc);
	if (item.stats.hasOwnProperty('eva') == true) BoostIntrinsics("eva",item.stats.eva);
	if (item.stats.hasOwnProperty('luck') == true) BoostIntrinsics("luck",item.stats.luck);
	
	var index = Inventory.equipment.indexOf(itemid);
	Inventory.equipment.splice(index,1);
	RefreshStatsPanel();
	RefreshInventoryMenu();
	RefreshButtons();
};

var BoostIntrinsics = function(stat,number){
    if (stat == "HP"){ 
		Player.maxHP += number;
		Player.HP += number;
		if (Player.maxHP > 80){ 
			Player.maxHP = 80;
			Player.HP = 80;
			window.alert("Note: this stat has been capped at 80.");
		};
	} else {
		Player[stat] += number;
		if (Player[stat] > 20){
			Player[stat] = 20;
			window.alert("This stat has been capped at 20.");
		};
	};
	RefreshStatsPanel();
};
var BoostExtrinsics = function(stat,number){
    if (stat == "armor") Player.armor += number;
	else if (stat == "HP"){
		Player.maxHP += number;
		Player.HP += number;
	} else {
		stat = "ext_"+stat;
		Player[stat] += number;
	};
	RefreshStatsPanel();
};
var UnboostExtrinsics = function(stat,number){
    if (stat == "armor") Player.armor -= number;
	else if (stat == "HP"){
		Player.maxHP -= number;
		if (Player.HP > Player.maxHP) Player.HP = Player.maxHP;
	} else {
		stat = "ext_"+stat;
		Player[stat] -= number;
	};
	RefreshStatsPanel();
};

//HEAD
var Helmet = {
	name: "Helmet",
	type: "equipment",
	slot: "head",
	restrictions: [],
	stats: {
		armor: 1
	},
	enchantable: true,
	EquipMessage: function(){ print("You put on the helmet.<br>") },
	UnequipMessage: function(){ print("You take off the helmet.<br>") },
	SlimeMessage: function(){ print("The helmet dissolves in your slime.<br>") },
	description: "<br><strong>Helmet</strong><br><br><em>Protects your head.</em><br><br>Head<br>+1 armor",
	value: 1
};
var Goggles = {
	name: "Goggles",
	type: "equipment",
	slot: "head",
	restrictions: [],
	stats: {
		acc: 1
	},
	enchantable: true,
	EquipMessage: function(){ print("You put on the goggles.<br>") },
	UnequipMessage: function(){ print("You take off the goggles.<br>") },
	SlimeMessage: function(){ print("The goggles dissolve in your slime.<br>") },
	description: "<br><strong>Goggles</strong><br><br><em>Fitted with special lenses to improve your vision.</em><br><br>Head<br>+1 acc",
	value: 1
};
//TORSO
var WizardRobes = {
	name: "Wizard Robes",
	type: "equipment",
	slot: "torso",
	restrictions: [],
	stats: {
		mag: 1
	},
	enchantable: true,
	EquipMessage: function(){ print("You put on the wizard robes.<br>") },
	UnequipMessage: function(){ print("You take off the wizard robes.<br>") },
	SlimeMessage: function(){ print("The robes melt in your slime.<br>") },
	description: "<br><strong>Wizard Robes</strong><br><br><em>A set of robes with magic stitched in.</em><br><br>Torso<br>+1 mag",
	value: 1,
};
var InvisibilityCloak = {
	name: "Invisibility Cloak",
	type: "equipment",
	slot: "torso",
	restrictions: [],
	stats: {
		eva: 4
	},
	enchantable: true,
	EquipMessage: function(){ print("You put on the cloak and your body fades from view.<br>") },
	UnequipMessage: function(){ print("You take off the cloak and your body reappears..<br>") },
	SlimeMessage: function(){ print("The cloak melts in your slime. Your slime becomes translucent.<br>") },
	description: "<br><strong>Invisibility Cloak</strong><br><br><em>A magical cloak.</em><br><br>Torso<br>+4 eva",
	value: 1,
};
//LEGS
var LeatherGreaves = {
	name: "Leather Greaves",
	type: "equipment",
	slot: "legs",
	restrictions: [],
	stats: {
		armor: 1
	},
	enchantable: true,
	EquipMessage: function(){ print("You put on the leather greaves.<br>") },
	UnequipMessage: function(){ print("You take off the greaves.<br>") },
	SlimeMessage: function(){ print("The leather greaves dissolve in your slime. You feel hardier.<br>") },
	description: "<br><strong>Leather Greaves</strong><br><br><em>Provides some protection to your legs.</em><br><br>Legs<br>+1 armor",
	value: 1,
};
var RunningBoots = {
	name: "Running Boots",
	type: "equipment",
	slot: "legs",
	restrictions: [],
	stats: {
		eva: 1
	},
	enchantable: true,
	EquipMessage: function(){ print("You put on the running boots.<br>") },
	UnequipMessage: function(){ print("You take off the boots.<br>") },
	SlimeMessage: function(){ print("You have no feet, so you don't bother trying to put these on.<br>") },
	NoSlime: true,
	description: "<br><strong>Running Boots</strong><br><br><em>Boots made for haste and agility.</em><br><br>Legs<br>+1 eva",
	value: 1,
};
//MISC
var LuckyCharm = {
	name: "Lucky Charm",
	type: "equipment",
	slot: "misc",
	restrictions: [],
	stats: {
		luck: 1
	},
	enchantable: true,
	EquipMessage: function(){ print("You wear the lucky charm.<br>") },
	UnequipMessage: function(){ print("You take off the lucky charm.<br>") },
	SlimeMessage: function(){ print("The charm dissolves in your slime.<br>") },
	description: "<br><strong>Lucky Charm</strong><br><br><em>A lucky charm.</em><br><br>Misc<br>+1 luck",
	value: 1
};
var Blindfold = {
	name: "Blindfold",
	type: "equipment",
	slot: "misc",
	restrictions: [],
	stats: {
		mag: 2,
		acc: -2
	},
	enchantable: true,
	EquipMessage: function(){ print("You put on the blindfold. As your vision fades, your mind opens.<br>") },
	UnequipMessage: function(){ print("You take off the blindfold.<br>") },
	SlimeMessage: function(){ print("You have no eyes to apply this to.<br>") },
	NoSlime: true,
	description: "<br><strong>Blindfold</strong><br><br><em>Prevents your mind from being distracted by sight.</em><br><br>Misc<br>+2 mag<br>-2 acc",
	value: 1,
};
var DungeonGauntlets = {
	name: "Dungeon Gauntlets",
	type: "equipment",
	slot: "misc",
	restrictions: [],
	stats: {
		armor: 1,
		str: 1,
		mag: 1,
		acc: 1,
		eva: 1,
		luck: 1
	},
	enchantable: false,
	EquipMessage: function(){ print("You put on the gauntlets.<br>") },
	UnequipMessage: function(){ print("You take off the gauntlets.<br>") },
	SlimeMessage: function(){ print("The gauntlets dissolve in your slime.<br>") },
	description: "<br><strong>Dungeon Gauntlets</strong><br><br><em>A pair of metal gauntlets made especially for adventuring in dungeons.</em>\
				  <br><br>Misc<br>+1 all stats",
	value: 5,
};
var MirrorShield = {
	name: "Mirror Shield",
	type: "equipment",
	slot: "misc",
	restrictions: [],
	stats: {
		eva: -2
	},
	enchantable: false,
	EquipMessage: function(){ print("You equip the mirror shield. It's heavy.<br>") },
	UnequipMessage: function(){ print("You put away the mirror shield.<br>") },
	SlimeMessage: function(){ print("This shield is too nice and shiny to get slime on.<br>") },
	NoSlime: true,
	description: "<br><strong>Mirror Shield</strong><br><br><em>A magic shield with a reflective face.</em>\
				  <br><br>Misc<br>-2 eva<br>Reflects damage",
	value: 5,
	onHit: function(dmg){
		print("The mirror shield returns some damage to the "+Enemy.name+".<br>");
		DamageEnemy(Math.floor(dmg/2));
	}
};
//WEAPON
var Dagger = {
	name: "Dagger",
	type: "equipment",
	slot: "weapon",
	restrictions: [],
	stats: {
		str: 1
	},
	enchantable: true,
	EquipMessage: function(){ print("You wield the dagger.<br>") },
	UnequipMessage: function(){ print("You put away the dagger.<br>") },
	SlimeMessage: function(){ print("The dagger sticks to your slime.<br>") },
	description: "<br><strong>Dagger</strong><br><br><em>A short blade for stabbing.</em><br><br>Weapon<br>+1 str",
	value: 1,
};
var Sword = {
	name: "Sword",
	type: "equipment",
	slot: "weapon",
	restrictions: [],
	stats: {
		str: 2
	},
	enchantable: true,
	EquipMessage: function(){ print("You wield the sword.<br>") },
	UnequipMessage: function(){ print("You put away the sword.<br>") },
	SlimeMessage: function(){ print("The sword sticks to your slime.<br>") },
	description: "<br><strong>Sword</strong><br><br><em>A big sharp sword.</em><br><br>Weapon<br>+2 str",
	value: 1,
};
var WarHammer = {
	name: "War Hammer",
	type: "equipment",
	slot: "weapon",
	restrictions: [],
	stats: {
		str: 3,
		eva: -3
	},
	enchantable: true,
	EquipMessage: function(){ print("You wield the war hammer. It's very heavy.<br>") },
	UnequipMessage: function(){ print("You put down the war hammer.<br>") },
	SlimeMessage: function(){ print("The hammer disintegrates in your slime. You feel much more solid.<br>") },
	description: "<br><strong>War Hammer</strong><br><br><em>A heavy iron war hammer.</em><br><br>Weapon<br>+3 str<br>-3 eva",
	value: 1,
};
var FlameSword = {
	name: "Flame Sword",
	type: "equipment",
	slot: "weapon",
	restrictions: [],
	stats: {
		str: 2
	},
	enchantable: true,
	EquipMessage: function(){ print("You wield the sword.<br>") },
	UnequipMessage: function(){ print("You put away the sword.<br>") },
	SlimeMessage: function(){ print("The sword sticks to your slime.<br>") },
	description: "<br><strong>Sword</strong><br><br><em>A big sharp sword. The blade is searing hot.</em><br><br>Weapon<br>+2 str<br>Does extra damage",
	value: 1,
	hit: function(){ 
		print("You hit the "+Enemy.name+". The "+Enemy.name+" is burnt by the sword.<br>");
		return Player.str+Player.ext_str+5;
	}
};
var Staff = {
	name: "Staff",
	type: "equipment",
	slot: "weapon",
	restrictions: [],
	stats: {
		str: 1,
		mag: 1
	},
	enchantable: true,
	EquipMessage: function(){ print("You wield the staff.<br>") },
	UnequipMessage: function(){ print("You put away the staff.<br>") },
	SlimeMessage: function(){ print("The staff breaks up in your slime.<br>") },
	description: "<br><strong>Sword</strong><br><br><em>A magical wooden staff.</em><br><br>Weapon<br>+1 str<br>+1 mag",
	value: 1,
	specialAttack: {
		name: "Blast",
		attack: function(){
			var dmg = 0;
			if (Player.acc+Player.ext_acc >= Enemy.stats.eva+(RNG(6)-3) || RNG(9)==0){
				print("You blast the "+Enemy.name+" with the staff.<br>");
				if (Player.mag+Player.ext_mag < 1) print("Your magical ability is to low to do any damage this way.");
				console.log(Player.mag+Player.ext_mag+" "+Enemy.stats.HP);
				return Player.mag+Player.ext_mag;
			} else {
				print("You miss the "+Enemy.name+".<br>");
				console.log("miss "+Enemy.stats.HP);
				return 0;
			};
		}
	}
};
