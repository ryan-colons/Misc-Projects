//Monsters

var AssembleMM = function(){
	MonsterManual = [ [],[] ];
	var MML = [MM1,MM2,MM3];
	for (i=0;i<=7;i++){ MonsterManual[0].push((PICK(MML))[0][i]) };
	for (i=0;i<=7;i++){ MonsterManual[1].push((MM3)[1][i]) };
};

var ChooseRoomMonster = function(n){
	if (MonsterManual == 0) AssembleMM();
	var block = Math.floor(n/5);
	return $.extend(true,{},PICK(MonsterManual[Floor-1][block]));
};

var MonsterManual = 0;	//	[ [],[] ];
var MMAppendix = {
	//Dungeon Guard Weapons
	MACE: 	{ weapon: "mace", 	str: 2, 		message: function(){ return "The "+Enemy.name+" bashes you with "+Enemy.GenPronoun+" mace.<br>"; } 			},
	SPEAR: 	{ weapon: "spear", 	acc: 2, 		message: function(){ return "The "+Enemy.name+" hits you with "+Enemy.GenPronoun+" spear.<br>"; }			},
	BOW:	{ weapon: "bow", 	eva: 2,			message: function(){ return "The "+Enemy.name+" fires an arrow at you.<br>"; }								},
	SHIELD:	{ weapon: "shield",	HP:  4, 		message: function(){ return "The "+Enemy.name+" knocks you over with "+Enemy.GenPronoun+" shield.<br>"; }	},
	SWORD: 	{ weapon: "sword",	str: 1, acc: 1, message: function(){ return "The "+Enemy.name+" slashes you with "+Enemy.GenPronoun+" sword.<br>"; }		},
	LANCE:	{ weapon: "lance", 	eva: 1, HP:  1, message: function(){ return "The "+Enemy.name+" hits you with "+Enemy.GenPronoun+" lance.<br>"; }			},
	//Dungeon Guard Armor
	BLACK: 	{ color: "<font style='color:black'>",
			  onHit: 	function(){
				//if the enemy has less than 1/4 of its maxHP left, it gets bigger (only once though)
				if (Enemy.stats.HP > 0){
					if (Enemy.hasOwnProperty("finalform")==false){
						if (Enemy.stats.HP < Enemy.stats.maxHP/4){
							print("The Dungeon Guard's black armor shines, and "+Enemy.SubjPronoun+" looks a little stronger.<br>");
							Enemy.stats.str += Math.floor(Enemy.stats.str/5);
							Enemy.stats.acc += Math.floor(Enemy.stats.acc/4);
							Enemy.finalform = true;
						};
					};
				};
			  }
			},
	BLUE: 	{ color: "<font style='color:blue'>",  
			  onHit: 	function(){ //enemy regains some health (1/5 of maxHP) 40% of the time
				if (Enemy.stats.HP >= 0){
					if (RNG(9)+1 > 6){
						Enemy.stats.HP += Math.floor(Enemy.stats.maxHP / 5);
						print(TEXT("The Dungeon Guard's armor shines blue, and "+Enemy.SubjPronoun+" looks a little healthier.<br>", "blue"));
					};
				};
			  }
			},
	RED:	{ color: "<font style='color:red'>",
			  atkchances: [35,35,30],
			  attack: 	function(){ //attack with 1.5*str and slightly lower acc
				print(TEXT("The Dungeon Guard's armor flashes red as "+Enemy.SubjPronoun+" attacks.<br>", "red"));
				if (Player.eva+Player.ext_eva+RNG(Player.luck)+(RNG(2)-2) > Enemy.stats.acc-RNG(2)){
					//you aren't hit
					print("The "+Enemy.name+" misses you.<br>");
					return "miss";
				} else {
					//you are hit
					print(TEXT(Enemy.hitMessage(), "red"));
					return (Enemy.stats.str*1.5);
				};	
			  }
			},
	GREEN:	{ color: "<font style='color:green'>",
			  atkchances: [40,40,20],
			  attack: 	function(){ //poisons the player - only happens once, no chance of missing
				print(TEXT("The Dungeon Guard's armor flashes green. You feel sick.<br>", "green"));
				Enemy.atkchances = [50,50,0];
				AddRoundCounter("PlayerPoison",5);
			  }
			},
	ORANGE:	{ color: "<font style='color:orange'>",
			  onHit: 	function(){ //deals 3 dmg to player 40% of the time
				if (Enemy.stats.HP > 0 && RNG(9)+1 > 6){
					print(TEXT("The Dungeon Guard's armor flashes orange. You are hurt.<br>", "orange"));
					DamagePlayer(3);
				};
			  },
			},
	PURPLE: { color: "<font style='color:purple'>",
			  onHit: 	function(){
				if (Enemy.stats.HP > 0 && RNG(9)+1 > 7 && RoundCounters.indexOf("DebuffPlayerSTR") == -1){
					print(TEXT("The Dungeon Guard's armor flashes purple. You feel weaker.<br>",'purple'));
					DebuffPlayerSTR.debuff = Math.floor(Player.str/4);
					AddRoundCounter("DebuffPlayerSTR",5);
				};
			  }
			},
};

var CreateExtraMonster = function(){
	var NewMonster = new Object();
	var Weapon = PICK([ MMAppendix.MACE, MMAppendix.SPEAR, MMAppendix.BOW, MMAppendix.SHIELD, MMAppendix.SWORD, MMAppendix.LANCE ]);
	var Armor = PICK([ MMAppendix.BLACK, MMAppendix.BLUE, MMAppendix.RED, MMAppendix.GREEN, MMAppendix.ORANGE, MMAppendix.PURPLE ]);
	NewMonster.SubjPronoun = PICK(["she", "he"]);
	if (NewMonster.SubjPronoun == "she") NewMonster.GenPronoun = "her";
	else NewMonster.GenPronoun = "his";
	
	NewMonster.name = Armor.color+"Dungeon Guard</font>";
	NewMonster.type = "Dungeon Guard";
	NewMonster.weapon = Weapon;
	NewMonster.armor = Armor;
	NewMonster.stats = new Object();
	NewMonster.getInfo = function(){
		var lvl = Math.floor(RoomsCleared/3);
		if (Enemy.weapon.hasOwnProperty("HP")) Enemy.stats.maxHP = Math.ceil((lvl+Enemy.weapon.HP)*1.5);
		else Enemy.stats.maxHP = Math.ceil(lvl*1.5);
		Enemy.stats.HP = Enemy.stats.maxHP;
		if (Enemy.weapon.hasOwnProperty("str")) Enemy.stats.str = (lvl+Enemy.weapon.str);
		else Enemy.stats.str = lvl;
		if (Enemy.weapon.hasOwnProperty("acc")) Enemy.stats.acc = (lvl+Enemy.weapon.acc);
		else Enemy.stats.acc = lvl;
		if (Enemy.weapon.hasOwnProperty("eva")) Enemy.stats.eva = (lvl+Enemy.weapon.eva);
		else Enemy.stats.eva = lvl;
	},
	NewMonster.drop = "";
	NewMonster.dropchance = 0;
	NewMonster.startsWithAVowel = false;
	NewMonster.hitMessage = Weapon.message;
	NewMonster.normalAttack = function(){
		//just like CEA.normal(), but this uses the special hit messages
		if (Player.eva+Player.ext_eva+RNG(Player.luck)+(RNG(2)-2) > Enemy.stats.acc+(RNG(2)-2)){
			//you aren't hit
			print("The "+Enemy.name+" misses you.<br>");
			return "miss";
		} else {
			//you are hit
			print(TEXT(Enemy.hitMessage(), "red"));
			return Enemy.stats.str;
		};
	};
	NewMonster.attacks = [CEA.normal, NewMonster.normalAttack];
	NewMonster.attackChances = [50,50];
	if (NewMonster.armor.hasOwnProperty('attack')){ 
		NewMonster.specialAttack = NewMonster.armor.attack;
		NewMonster.attacks.push(NewMonster.specialAttack);
		NewMonster.attackChances = NewMonster.armor.atkchances;
	};
	if (NewMonster.armor.hasOwnProperty('onHit')) NewMonster.onHit = NewMonster.armor.onHit;
	else NewMonster.onHit = function(){};
	
	return NewMonster;
};
var ChooseRoomBoss = function(){
	var l = [Hydra, Dragon];
	return l[Floor-1];
};

var Hydra = {
	name: "hydra",
	type: "dragon",
	stats: {
		maxHP: 25,
		HP: 25,
		str: 3,
		acc: 7,
		eva: 5,
		heads: 1
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){
		for (n=0;n<Enemy.stats.heads;n++){
			var dmg = 0;
			if (Player.eva+Player.ext_eva+RNG(Player.luck)+(RNG(2)-2) > Enemy.stats.acc+(RNG(2)-2)){
				//you aren't hit
				print("The "+Enemy.name+" misses you.<br>");
			} else {
				//you are hit
				print(TEXT("The "+Enemy.name+" hits you.<br>","red"));
				dmg += Enemy.stats.str;
			};
		};
		if (dmg == 0) return "miss";
		else return  dmg;
	},
	onHit: function(dmg){
		if (dmg > 5 && RNG(1) == 1 && Enemy.stats.HP > 0){
			print("The hydra grows another head!<br>");
			Hydra.stats.heads += 1;
		};
	},
	getInfo: function(){
		Hydra.attacks = [Hydra.specialAttack];
		Hydra.attackChances = [100];
	}
};
var Dragon = {
		name: "dragon",
		type: "dragon",
		stats: {
			maxHP: 50,
			HP: 50,
			str: 6,
			acc: 14,
			eva: 10
		},
		drop: "placeholder",
		dropchance: 0,
		startsWithAVowel: false,
		specialAttack: function(){}, //optional
		onHit: function(){},
		attacks: [CEA.normal],
		attackChances: [100]
	};


//**MM1 PAGE ONE**// 1 stat point				
var Rat = {
	name: "rat",
	type: "animal",
	stats: {
		maxHP: 3,
		HP: 3,
		str: 1,
		acc: 2,
		eva: 1
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Bat = {
	name: "bat",
	type: "animal",
	stats: {
		maxHP: 3,
		HP: 3,
		str: 1,
		acc: 1,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Spider = {
	name: "spider",
	type: "animal",
	stats: {
		maxHP: 3,
		HP: 3,
		str: 2,
		acc: 1,
		eva: 1
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Lizard = {
	name: "lizard",
	type: "animal",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 1,
		acc: 1,
		eva: 1
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Snake = {
	name: "snake",
	type: "animal",
	stats: {
		maxHP: 3,
		HP: 3,
		str: 2,
		acc: 2,
		eva: 1
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM1 PAGE TWO**// 3 stat points
var Dog = {
	name: "dog",
	type: "animal",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 1,
		acc: 2,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Boar = {
	name: "boar",
	type: "animal",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 1,
		acc: 2,
		eva: 1
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Salamander = {
	name: "salamander",
	type: "animal",
	stats: {
		maxHP: 3,
		HP: 3,
		str: 2,
		acc: 2,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Fox = {
	name: "fox",
	type: "animal",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 1,
		acc: 2,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Badger = {
	name: "badger",
	type: "animal",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 1,
		acc: 3,
		eva: 1
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM1 PAGE THREE**// 5 stat points
var GiantCrab = {
	name: "giant crab",
	type: "animal",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 2,
		acc: 2,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Hound = {
	name: "hound",
	type: "animal",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 2,
		acc: 2,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Hawk = {
	name: "hawk",
	type: "animal",
	stats: {
		maxHP: 3,
		HP: 3,
		str: 1,
		acc: 4,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Wolf = {
	name: "wolf",
	type: "animal",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 3,
		acc: 2,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GiantToad = {
	name: "giant toad",
	type: "animal",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 2,
		acc: 2,
		eva: 1
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM1 PAGE FOUR**// 7 stat points
var Tiger = {
	name: "tiger",
	type: "animal",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 3,
		acc: 3,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Lion = {
	name: "lion",
	type: "animal",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 3,
		acc: 2,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Sandworm = {
	name: "sandworm",
	type: "animal",
	stats: {
		maxHP: 3,
		HP: 3,
		str: 3,
		acc: 3,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Hippo = {
	name: "hippo",
	type: "animal",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 3,
		acc: 2,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Scorpion = {
	name: "scorpion",
	type: "animal",
	stats: {
		maxHP: 3,
		HP: 3,
		str: 3,
		acc: 5,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM1 PAGE FIVE**// 9 stat points
var Hyena = {
	name: "hyena",
	type: "animal",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 3,
		acc: 4,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Bear = {
	name: "bear",
	type: "animal",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 2,
		acc: 4,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var MountainLion = {
	name: "mountain lion",
	type: "animal",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 2,
		acc: 4,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Crocodile = {
	name: "crocodile",
	type: "animal",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 4,
		acc: 3,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Rhinocerous = {
	name: "rhinocerous",
	type: "animal",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 4,
		acc: 4,
		eva: 1
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM1 PAGE SIX**// 11 stat points
var Elephant = {
	name: "elephant",
	type: "animal",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 4,
		acc: 4,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Troglodyte = {
	name: "troglodyte",
	type: "beast",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 2,
		acc: 6,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GiantScorpion = {
	name: "giant scorpion",
	type: "animal",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 5,
		acc: 5,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Serpent = {
	name: "serpent",
	type: "animal",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 3,
		acc: 5,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GiantSpider = {
	name: "giant spider",
	type: "animal",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 3,
		acc: 5,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};				
//**MM1 PAGE SIX**// 13 stat points
var Chupacabra = {
	name: "chupacabra",
	type: "beast",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 4,
		acc: 4,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};		
var GrizzlyBear = {
	name: "grizzly bear",
	type: "animal",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 5,
		acc: 4,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};			
var GiantCrocodile = {
	name: "giant crocodile",
	type: "animal",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 6,
		acc: 5,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};		
var Harpy = {
	name: "harpy",
	type: "animal",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 3,
		acc: 6,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};				
var GiantSquid = {
	name: "giant squid",
	type: "animal",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 3,
		acc: 6,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM1 PAGE SEVEN**// 15 stat points
var Owlbear = {
	name: "owlbear",
	type: "beast",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 4,
		acc: 5,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Manticore = {
	name: "manticore",
	type: "beast",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 4,
		acc: 6,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Chimera = {
	name: "chimera",
	type: "beast",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 4,
		acc: 5,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Basilisk = {
	name: "basilisk",
	type: "animal",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 4,
		acc: 5,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Unicorn = {
	name: "unicorn",
	type: "animal",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 4,
		acc: 4,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};

//**MM1 PAGE EIGHT**// 17 stat points
var Minotaur = {
	name: "minotaur",
	type: "beast",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 5,
		acc: 6,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Centaur = {
	name: "Centaur",
	type: "beast",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 4,
		acc: 7,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var BlackUnicorn = {
	name: "black unicorn",
	type: "animal",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 5,
		acc: 5,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Gorgon = {
	name: "gorgon",
	type: "beast",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 3,
		acc: 6,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Hippogriff = {
	name: "hippogriff",
	type: "beast",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 5,
		acc: 5,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};	
//**MM1 PAGE NINE**// 19 stat points
var MinotaurWarrior = {
	name: "minotaur warrior",
	type: "beast",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 5,
		acc: 8,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var CentaurArcher = {
	name: "centaur archer",
	type: "beast",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 4,
		acc: 7,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};	
var Siren = {
	name: "siren",
	type: "beast",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 6,
		acc: 6,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Sphinx = {
	name: "sphinx",
	type: "beast",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 5,
		acc: 6,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var WoodNymph = {
	name: "wood nymph",
	type: "beast",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 5,
		acc: 5,
		eva: 8
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM1 PAGE TEN**// 21 stat points
var MinotaurLord = {
	name: "minotaur lord",
	type: "beast",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 6,
		acc: 8,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var HighCentaur = {
	name: "High centaur",
	type: "beast",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 5,
		acc: 7,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};	
var Phoenix = {
	name: "phoenix",
	type: "animal",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 5,
		acc: 7,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};	
var WaterNymph = {
	name: "water nymph",
	type: "beast",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 5,
		acc: 7,
		eva: 8
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};	
var Griffin = {
	name: "griffin",
	type: "beast",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 7,
		acc: 8,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM1 PAGE ELEVEN**// 23 stat points
var BloodNymph = {
	name: "blood nymph",
	type: "beast",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 4,
		acc: 9,
		eva: 8
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Wyvern = {
	name: "wyvern",
	type: "dragon",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 5,
		acc: 7,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Cockatrice = {
	name: "cockatrice",
	type: "beast",
	stats: {
		maxHP: 15,
		HP: 15,
		str: 7,
		acc: 6,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Roc = {
	name: "roc",
	type: "animal",
	stats: {
		maxHP: 17,
		HP: 17,
		str: 6,
		acc: 6,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Satyr = {
	name: "satyr",
	type: "beast",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 7,
		acc: 8,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM1 PAGE TWELVE**// 25 stat points
var SatyrArcher = {
	name: "satyr archer",
	type: "beast",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 7,
		acc: 9,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Tonberry = {
	name: "tonberry",
	type: "Tonberry",
	stats: {
		maxHP: 29,
		HP: 29,
		str: 2,
		acc: 2,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Djinn = {
	name: "djinn",
	type: "magical",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 10,
		acc: 7,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100],
};
var StoneGolem = {
	name: "stone golem",
	type: "golem",
	stats: {
		maxHP: 23,
		HP: 23,
		str: 7,
		acc: 6,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var FireElemental = {
	name: "fire elemental",
	type: "magical",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 8,
		acc: 9,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM1 PAGE THIRTEEN**// 27 stat points
var SatyrMagician = {
	name: "satyr magician",
	type: "beast",
	stats: {
		maxHP: 15,
		HP: 15,
		str: 7,
		acc: 9,
		eva: 8
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var SteelGolem = {
	name: "steel golem",
	type: "golem",
	stats: {
		maxHP: 23,
		HP: 23,
		str: 7,
		acc: 7,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var WaterElemental = {
	name: "water elemental",
	type: "magical",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 9,
		acc: 8,
		eva: 9
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Behemoth = {
	name: "behemoth",
	type: "beast",
	stats: {
		maxHP: 21,
		HP: 21,
		str: 9,
		acc: 7,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Ent = {
	name: "ent",
	type: "magical",
	stats: {
		maxHP: 15,
		HP: 15,
		str: 8,
		acc: 8,
		eva: 8
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM1 PAGE FOURTEEN**// 29 stat points
var EarthElemental = {
	name: "earth elemental",
	type: "magical",
	stats: {
		maxHP: 19,
		HP: 19,
		str: 9,
		acc: 8,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var IceGolem = {
	name: "ice golem",
	type: "golem",
	stats: {
		maxHP: 23,
		HP: 23,
		str: 8,
		acc: 8,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var MasterTonberry = {
	name: "Master tonberry",
	type: "Tonberry",
	stats: {
		maxHP: 35,
		HP: 35,
		str: 5,
		acc: 5,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Giant = {
	name: "giant",
	type: "giant",
	stats: {
		maxHP: 19,
		HP: 19,
		str: 9,
		acc: 9,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Fairy = {
	name: "fairy",
	type: "magical",
	stats: {
		maxHP: 15,
		HP: 15,
		str: 7,
		acc: 9,
		eva: 10
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM1 PAGE FIFTEEN**// 32 stat points
var AirElemental = {
	name: "air elemental",
	type: "magical",
	stats: {
		maxHP: 17,
		HP: 17,
		str: 8,
		acc: 10,
		eva: 10
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var FleshGolem = {
	name: "flesh golem",
	type: "golem",
	stats: {
		maxHP: 25,
		HP: 25,
		str: 8,
		acc: 8,
		eva: 8
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};

var MM1 = [ //Animals, Beasts, etc
					 [/*1-4*/		[Rat, Bat, Spider, Lizard, Snake], 
					 /*6-9*/		[Dog, Boar, Salamander, Fox, Badger],
					 /*11-14*/		[GiantCrab, Hound, Hawk, Wolf, GiantToad],
					 /*16-19*/		[Tiger, Lion, Sandworm, Hippo, Scorpion],
					 /*21-24*/		[Hyena, Bear, MountainLion, Crocodile, Rhinocerous],
					 /*26-29*/		[Elephant, Troglodyte, GiantScorpion, Serpent, GiantSpider],
					 /*31-34*/		[Chupacabra, GrizzlyBear, GiantCrocodile, Harpy, GiantSquid],
					 /*36-39*/		[Owlbear, Manticore, Chimera, Basilisk, Unicorn],
					 ],
					 [/*1-4*/		[Minotaur, Centaur, BlackUnicorn, Gorgon, Hippogriff], 
					 /*6-9*/		[MinotaurWarrior, CentaurArcher, Siren, Sphinx, WoodNymph],
					 /*11-14*/		[MinotaurLord, HighCentaur, Phoenix, WaterNymph, Griffin],
					 /*16-19*/		[BloodNymph, Wyvern, Cockatrice, Roc, Satyr],
					 /*21-24*/		[SatyrArcher, Tonberry, Djinn, StoneGolem, FireElemental],
					 /*26-29*/		[SatyrMagician, SteelGolem, WaterElemental, Behemoth, Ent],
					 /*31-34*/		[EarthElemental, IceGolem, MasterTonberry, Giant, Fairy],
					 /*36-39*/		[AirElemental, FleshGolem, EliteDungeonGuard],
					 ]
	            ];
				
//**MM2 PAGE TWO**// 3 stat points
var GreyOoze = {
	name: "grey ooze",
	type: "slime",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 2,
		acc: 1,
		eva: 1
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var SmallSlime = {
	name: "small slime",
	type: "slime",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 1,
		acc: 2,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Mudman = {
	name: "mudman",
	type: "slime",
	stats: {
		maxHP: 3,
		HP: 3,
		str: 2,
		acc: 2,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GreyTentacle = {
	name: "grey tentacle",
	type: "slime",
	stats: {
		maxHP: 3,
		HP: 3,
		str: 4,
		acc: 1,
		eva: 1
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GreySludge = {
	name: "grey sludge",
	type: "slime",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 1,
		acc: 1,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM2 PAGE THREE**// 5 stat points
var Imp = {
	name: "imp",
	type: "demon",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 1,
		acc: 3,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var ZombieRat = {
	name: "zombie rat",
	type: "undead",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 2,
		acc: 2,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Spirit = {
	name: "spirit",
	type: "undead",
	stats: {
		maxHP: 3,
		HP: 3,
		str: 2,
		acc: 3,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Hellcat = {
	name: "hellcat",
	type: "demon",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 1,
		acc: 3,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var FloatingEye = {
	name: "floating eye",
	type: "slime",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 1,
		acc: 5,
		eva: 1
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM2 PAGE FOUR**// 7 stat points
var BlackOoze = {
	name: "black ooze",
	type: "slime",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 3,
		acc: 2,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Slime = {
	name: "slime",
	type: "slime",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 2,
		acc: 3,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var MudmanWarrior = {
	name: "mudman warrior",
	type: "slime",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 3,
		acc: 4,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GelatinousCube = {
	name: "gelatinous cube",
	type: "slime",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 2,
		acc: 3,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var BlackSludge = {
	name: "black sludge",
	type: "slime",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 2,
		acc: 2,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM2 PAGE FIVE**// 9 stat points
var Skeleton = {
	name: "skeleton",
	type: "undead",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 3,
		acc: 4,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Zombie = {
	name: "zombie",
	type: "undead",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 3,
		acc: 4,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Ghost = {
	name: "ghost",
	type: "undead",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 3,
		acc: 3,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Ghoul = {
	name: "ghoul",
	type: "undead",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 3,
		acc: 4,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var SludgeGolem = {
	name: "sludge golem",
	type: "slime",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 2,
		acc: 3,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM2 PAGE SIX**// 11 stat points
var YellowOoze = {
	name: "yellow ooze",
	type: "slime",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 5,
		acc: 3,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Hellhound = {
	name: "hellhound",
	type: "demon",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 4,
		acc: 5,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Devil = {
	name: "devil",
	type: "demon",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 3,
		acc: 5,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GiantSlime = {
	name: "giant slime",
	type: "slime",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 3,
		acc: 4,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Shade = {
	name: "shade",
	type: "undead",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 4,
		acc: 5,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM2 PAGE SEVEN**// 13 stat points
var Vampire = {
	name: "vampire",
	type: "undead",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 4,
		acc: 5,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var KoboldZombie = {
	name: "kobold zombie",
	type: "undead",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 4,
		acc: 6,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var MudmanShaman = {
	name: "mudman shaman",
	type: "slime",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 4,
		acc: 4,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var SkeletonSoldier = {
	name: "skeleton soldier",
	type: "undead",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 3,
		acc: 5,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Wraith = {
	name: "wraith",
	type: "undead",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 5,
		acc: 5,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM2 PAGE EIGHT**// 15 stat points
var Wight = {
	name: "wight",
	type: "undead",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 5,
		acc: 5,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var BugbearSkeleton = {
	name: "bugbear skeleton",
	type: "undead",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 6,
		acc: 5,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var MudmanLord = {
	name: "mudman lord",
	type: "slime",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 4,
		acc: 4,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var PurpleSlime = {
	name: "purple slime",
	type: "slime",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 3,
		acc: 5,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Demon = {
	name: "demon",
	type: "demon",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 5,
		acc: 5,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};

//**MM2 PAGE NINE**// 17 stat points
var Banshee = {
	name: "banshee",
	type: "undead",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 6,
		acc: 7,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Necromancer = {
	name: "necromancer",
	type: "humanoid",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 3,
		acc: 8,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var VampireWarrior = {
	name: "vampire warrior",
	type: "undead",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 5,
		acc: 6,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Shadow = {
	name: "shadow",
	type: "undead",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 5,
		acc: 7,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var PurpleOoze = {
	name: "purple ooze",
	type: "slime",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 7,
		acc: 5,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM2 PAGE TEN**// 19 stat points
var VampireMage = {
	name: "vampire mage",
	type: "undead",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 4,
		acc: 7,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Winterwight = {
	name: "winterwight",
	type: "undead",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 5,
		acc: 6,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var SludgeMage = {
	name: "sludge mage",
	type: "slime",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 5,
		acc: 6,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GreatShadow = {
	name: "great shadow",
	type: "undead",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 5,
		acc: 6,
		eva: 8
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Mudbeast = {
	name: "mudbeast",
	type: "slime",
	stats: {
		maxHP: 15,
		HP: 15,
		str: 4,
		acc: 5,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM2 PAGE ELEVEN**// 21 stat points
var VampireLord = {
	name: "vampire lord",
	type: "undead",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 5,
		acc: 8,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var ShadowMage = {
	name: "shadow mage",
	type: "undead",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 4,
		acc: 8,
		eva: 9
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Poltergeist = {
	name: "poltergeist",
	type: "undead",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 6,
		acc: 7,
		eva: 8
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GreenSlime = {
	name: "green slime",
	type: "slime",
	stats: {
		maxHP: 15,
		HP: 15,
		str: 5,
		acc: 7,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Mummy = {
	name: "mummy",
	type: "undead",
	stats: {
		maxHP: 15,
		HP: 15,
		str: 7,
		acc: 7,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM2 PAGE TWELVE**// 23 stat points
var GreatNecromancer = {
	name: "great necromancer",
	type: "humanoid",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 5,
		acc: 8,
		eva: 8
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var DwarfZombie = {
	name: "dwarf zombie",
	type: "undead",
	stats: {
		maxHP: 15,
		HP: 15,
		str: 7,
		acc: 8,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var AcidToad = {
	name: "acid zombie",
	type: "slime",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 9,
		acc: 9,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var BoneGolem = {
	name: "bone golem",
	type: "golem",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 7,
		acc: 7,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var DemonWarrior = {
	name: "demon warrior",
	type: "demon",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 6,
		acc: 8,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM2 PAGE THIRTEEN**// 25 stat points
var ElfZombie = {
	name: "elf zombie",
	type: "undead",
	stats: {
		maxHP: 17,
		HP: 17,
		str: 7,
		acc: 8,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var OgreSkeleton = {
	name: "ogre skeleton",
	type: "undead",
	stats: {
		maxHP: 15,
		HP: 15,
		str: 7,
		acc: 9,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var MummyKing = {
	name: "mummy king",
	type: "undead",
	stats: {
		maxHP: 19,
		HP: 19,
		str: 6,
		acc: 7,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var OozeBeast = {
	name: "ooze beast",
	type: "slime",
	stats: {
		maxHP: 15,
		HP: 15,
		str: 9,
		acc: 9,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var DemonWarlock = {
	name: "demon warlock",
	type: "demon",
	stats: {
		maxHP: 15,
		HP: 15,
		str: 6,
		acc: 10,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM2 PAGE FOURTEEN**// 27 stat points
var PinkOoze = {
	name: "pink ooze",
	type: "slime",
	stats: {
		maxHP: 17,
		HP: 17,
		str: 8,
		acc: 9,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var ArmoredDevil = {
	name: "armored devil",
	type: "demon",
	stats: {
		maxHP: 23,
		HP: 23,
		str: 7,
		acc: 8,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};  
var TrollSkeleton = {
	name: "troll skeleton",
	type: "undead",
	stats: {
		maxHP: 15,
		HP: 15,
		str: 8,
		acc: 8,
		eva: 8
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var SkeletalWizard = {
	name: "skeletal wizard",
	type: "undead",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 9,
		acc: 7,
		eva: 9
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var DemonLord = {
	name: "demon lord",
	type: "demon",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 9,
		acc: 10,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM2 PAGE FIFTEEN**// 29 stat points
var SlimeKing = {
	name: "slime king",
	type: "slime",
	stats: {
		maxHP: 23,
		HP: 23,
		str: 6,
		acc: 9,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var PinkSlime = {
	name: "pink slime",
	type: "slime",
	stats: {
		maxHP: 15,
		HP: 15,
		str: 9,
		acc: 11,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var ShadowBeast = {
	name: "shadow beast",
	type: "undead",
	stats: {
		maxHP: 19,
		HP: 19,
		str: 6,
		acc: 8,
		eva: 10
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var SludgeColossus = {
	name: "sludge colossus",
	type: "slime",
	stats: {
		maxHP: 27,
		HP: 27,
		str: 8,
		acc: 8,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var ImpMaster = {
	name: "imp master",
	type: "demon",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 6,
		acc: 10,
		eva: 12
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM2 PAGE SIXTEEN**// 32 stat points
var Lich = {
	name: "lich",
	type: "undead",
	stats: {
		maxHP: 23,
		HP: 23,
		str: 8,
		acc: 10,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var AmorphousOoze = {
	name: "amorphous ooze",
	type: "slime",
	stats: {
		maxHP: 19,
		HP: 19,
		str: 9,
		acc: 9,
		eva: 9
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};

var MM2 = [ //Slimes, Undead, Demons
					 [/*1-4*/		[Rat, Bat, Spider, Lizard, Snake], 
					 /*6-9*/		[GreyOoze, SmallSlime, Mudman, GreyTentacle, GreySludge],
					 /*11-14*/		[Imp, ZombieRat, Spirit, Hellcat, FloatingEye],
					 /*16-19*/		[BlackOoze, Slime, MudmanWarrior, GelatinousCube, BlackSludge],
					 /*21-24*/		[Skeleton, Zombie, Ghost, Ghoul, SludgeGolem],
					 /*26-29*/		[YellowOoze, Hellhound, Devil, GiantSlime, Shade],
					 /*31-34*/		[Vampire, KoboldZombie, MudmanShaman, SkeletonSoldier, Wraith],
					 /*36-39*/		[Wight, BugbearSkeleton, MudmanLord, PurpleSlime, Demon],
					 ],
					 [/*1-4*/		[Banshee, Necromancer, VampireWarrior, Shadow, PurpleOoze], 
					 /*6-9*/		[VampireMage, Winterwight, SludgeMage, GreatShadow, Mudbeast],
					 /*11-14*/		[VampireLord, ShadowMage, Poltergeist, GreenSlime, Mummy],
					 /*16-19*/		[GreatNecromancer, DwarfZombie, AcidToad, BoneGolem, DemonWarrior],
					 /*21-24*/		[ElfZombie, OgreSkeleton, MummyKing, OozeBeast, DemonWarlock],
					 /*26-29*/		[PinkOoze, ArmoredDevil, TrollSkeleton, SkeletalWizard, DemonLord],
					 /*31-34*/		[SlimeKing, PinkSlime, ShadowBeast, SludgeColossus, ImpMaster],
					 /*36-39*/		[Lich, AmorphousOoze, EliteDungeonGuard],
					 ]
	            ];

//**MM3 PAGE THREE**// 5 stat points
var Kobold = {
	name: "kobold",
	type: "humanoid",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 2,
		acc: 3,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};				
var Gnome = {
	name: "gnome",
	type: "humanoid",
	stats: {
		maxHP: 3,
		HP: 3,
		str: 1,
		acc: 3,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Goblin = {
	name: "goblin",
	type: "humanoid",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 3,
		acc: 2,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var BugbearCub = {
	name: "bugbear cub",
	type: "beast",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 3,
		acc: 2,
		eva: 1
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GnollPup = {
	name: "gnoll pup",
	type: "beast",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 2,
		acc: 3,
		eva: 1
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM3 PAGE FOUR**// 7 stat points
var KoboldWarrior = {
	name: "kobold warrior",
	type: "humanoid",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 2,
		acc: 4,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GnomeWarrior = {
	name: "gnome warrior",
	type: "humanoid",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 2,
		acc: 3,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GoblinShaman = {
	name: "goblin shaman",
	type: "humanoid",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 2,
		acc: 4,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Bugbear = {
	name: "bugbear",
	type: "beast",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 3,
		acc: 2,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Gnoll = {
	name: "gnoll",
	type: "beast",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 2,
		acc: 3,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM3 PAGE FIVE**// 9 stat points
var KoboldShaman = {
	name: "kobold shaman",
	type: "humanoid",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 2,
		acc: 5,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GnomeRogue = {
	name: "gnome rogue",
	type: "humanoid",
	stats: {
		maxHP: 5,
		HP: 5,
		str: 2,
		acc: 4,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GoblinMarauder = {
	name: "goblin marauder",
	type: "humanoid",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 3,
		acc: 5,
		eva: 1
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GreatBugbear = {
	name: "bugbear",
	type: "beast",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 3,
		acc: 3,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GnollWarrior = {
	name: "gnoll warrior",
	type: "beast",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 3,
		acc: 4,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM3 PAGE SIX**// 11 stat points
var KoboldAssassin = {
	name: "kobold assassin",
	type: "humanoid",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 1,
		acc: 5,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GnomeMage = {
	name: "gnome mage",
	type: "humanoid",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 3,
		acc: 4,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GoblinSoldier = {
	name: "goblin soldier",
	type: "humanoid",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 3,
		acc: 5,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Orc = {
	name: "orc",
	type: "humanoid",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 4,
		acc: 5,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Ogre = {
	name: "ogre",
	type: "humanoid",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 3,
		acc: 4,
		eva: 2
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM3 PAGE SEVEN**// 13 stat points
var Dwarf = {
	name: "dwarf",
	type: "humanoid",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 3,
		acc: 4,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Elf = {
	name: "elf",
	type: "humanoid",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 3,
		acc: 5,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var HumanFighter = {
	name: "human fighter",
	type: "humanoid",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 4,
		acc: 5,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var HumanMage = {
	name: "human mage",
	type: "humanoid",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 5,
		acc: 4,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var HumanRogue = {
	name: "human rogue",
	type: "humanoid",
	stats: {
		maxHP: 7,
		HP: 7,
		str: 3,
		acc: 6,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM3 PAGE EIGHT**// 15 stat points
var HillDwarf = {
	name: "hill dwarf",
	type: "humanoid",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 4,
		acc: 5,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var ElfWarrior = {
	name: "elf warrior",
	type: "humanoid",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 3,
		acc: 7,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var OrcWarrior = {
	name: "orc warrior",
	type: "humanoid",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 4,
		acc: 6,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GreatOgre = {
	name: "great ogre",
	type: "humanoid",
	stats: {
		maxHP: 15,
		HP: 15,
		str: 4,
		acc: 5,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var KoboldLord = {
	name: "kobold lord",
	type: "humanoid",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 3,
		acc: 5,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};

//**MM3 PAGE NINE**// 17 stat points
var Haemogoblin = {
	name: "haemogoblin",
	type: "humanoid",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 5,
		acc: 5,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Hobgoblin = {
	name: "hobgoblin",
	type: "humanoid",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 5,
		acc: 7,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var ElfMage = {
	name: "elf mage",
	type: "humanoid",
	stats: {
		maxHP: 9,
		HP: 9,
		str: 6,
		acc: 5,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var DarkElf = {
	name: "dark elf",
	type: "humanoid",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 5,
		acc: 6,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var DwarfWarrior = {
	name: "dwarf warrior",
	type: "humanoid",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 3,
		acc: 6,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM3 PAGE TEN**// 19 stat points
var HighElf = {
	name: "high elf",
	type: "humanoid",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 6,
		acc: 9,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Troll = {
	name: "troll",
	type: "giant",
	stats: {
		maxHP: 15,
		HP: 15,
		str: 8,
		acc: 5,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Cyclops = {
	name: "cyclops",
	type: "giant",
	stats: {
		maxHP: 15,
		HP: 15,
		str: 5,
		acc: 8,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var HobgoblinWarrior = {
	name: "hobgoblin warrior",
	type: "humanoid",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 6,
		acc: 6,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Thief = {
	name: "thief",
	type: "humanoid",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 3,
		acc: 7,
		eva: 9
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM3 PAGE ELEVEN**// 21 stat points
var Summoner = {
	name: "summoner",
	type: "humanoid",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 3,
		acc: 8,
		eva: 8
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var CaveTroll = {
	name: "cave troll",
	type: "giant",
	stats: {
		maxHP: 17,
		HP: 17,
		str: 8,
		acc: 6,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Leprechaun = {
	name: "leprechaun",
	type: "humanoid",
	stats: {
		maxHP: 11,
		HP: 11,
		str: 5,
		acc: 6,
		eva: 9
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Angel = {
	name: "angel",
	type: "angel",
	stats: {
		maxHP: 13,
		HP: 13,
		str: 6,
		acc: 6,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var HalfOrc = {
	name: "half-orc",
	type: "humanoid",
	stats: {
		maxHP: 15,
		HP: 15,
		str: 6,
		acc: 6,
		eva: 6
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM3 PAGE TWELVE**// 23 stat points
var Warlock = {
	name: "warlock",
	type: "humanoid",
	stats: {
		maxHP: 17,
		HP: 17,
		str: 8,
		acc: 5,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var TrollShaman = {
	name: "troll shaman",
	type: "giant",
	stats: {
		maxHP: 21,
		HP: 21,
		str: 8,
		acc: 7,
		eva: 3
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var CyclopsWarrior = {
	name: "cyclops warrior",
	type: "giant",
	stats: {
		maxHP: 19,
		HP: 19,
		str: 7,
		acc: 8,
		eva: 4
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Knight = {
	name: "knight",
	type: "humanoid",
	stats: {
		maxHP: 15,
		HP: 15,
		str: 5,
		acc: 8,
		eva: 8
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Barbarian = {
	name: "barbarian",
	type: "humanoid",
	stats: {
		maxHP: 21,
		HP: 21,
		str: 8,
		acc: 5,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM3 PAGE THIRTEEN**// 25 stat points
var DwarfArchitect = {
	name: "dwarf architect",
	type: "humanoid",
	stats: {
		maxHP: 19,
		HP: 19,
		str: 7,
		acc: 7,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var MirrorMage = {
	name: "mirror mage",
	type: "humanoid",
	stats: {
		maxHP: 17,
		HP: 17,
		str: 7,
		acc: 7,
		eva: 8
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GoblinOozeSlinger = {
	name: "goblin ooze-slinger",
	type: "humanoid",
	stats: {
		maxHP: 17,
		HP: 17,
		str: 7,
		acc: 8,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GnomePyromancer = {
	name: "gnome pyromancer",
	type: "humanoid",
	stats: {
		maxHP: 19,
		HP: 19,
		str: 7,
		acc: 5,
		eva: 9
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var ElfMonk = {
	name: "elf monk",
	type: "humanoid",
	stats: {
		maxHP: 15,
		HP: 15,
		str: 7,
		acc: 9,
		eva: 7
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM3 PAGE FOURTEEN**// 27 stat points
var OneWingedAngel = {
	name: "one-winged angel",
	type: "angel",
	stats: {
		maxHP: 17,
		HP: 17,
		str: 7,
		acc: 9,
		eva: 8
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var GnomeBard = {
	name: "gnome bard",
	type: "humanoid",
	stats: {
		maxHP: 17,
		HP: 17,
		str: 8,
		acc: 8,
		eva: 8
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var HighKnight = {
	name: "high knight",
	type: "humanoid",
	stats: {
		maxHP: 21,
		HP: 21,
		str: 6,
		acc: 8,
		eva: 8
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var ArmoredCyclops = {
	name: "armored cyclops",
	type: "humanoid",
	stats: {
		maxHP: 23,
		HP: 23,
		str: 6,
		acc: 10,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: true,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var Heretic = {
	name: "heretic",
	type: "humanoid",
	stats: {
		maxHP: 17,
		HP: 17,
		str: 6,
		acc: 10,
		eva: 8
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM3 PAGE FIFTEEN**// 29 stat points
var SwampTroll = {
	name: "swamp troll",
	type: "giant",
	stats: {
		maxHP: 27,
		HP: 27,
		str: 8,
		acc: 7,
		eva: 5
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var ChaosDruid = {
	name: "chaos druid",
	type: "humanoid",
	stats: {
		maxHP: 19,
		HP: 19,
		str: 9,
		acc: 9,
		eva: 8
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var ForgottenWarrior = {
	name: "forgotten warrior",
	type: "humanoid",
	stats: {
		maxHP: 21,
		HP: 21,
		str: 6,
		acc: 10,
		eva: 8
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var MindFlayer = {
	name: "mind flayer",
	type: "humanoid",
	stats: {
		maxHP: 17,
		HP: 17,
		str: 8,
		acc: 8,
		eva: 11
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var DragonTrainer = {
	name: "dragon trainer",
	type: "humanoid",
	stats: {
		//same as chaos druid at the moment
		maxHP: 19,
		HP: 19,
		str: 9,
		acc: 9,
		eva: 8
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
//**MM3 PAGE SIXTEEN**// 32 stat points
var Warlord = {
	name: "warlord",
	type: "humanoid",
	stats: {
		maxHP: 21,
		HP: 21,
		str: 9,
		acc: 9,
		eva: 9
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};
var MasterAngel = {
	name: "master angel",
	type: "angel",
	stats: {
		maxHP: 21,
		HP: 21,
		str: 8,
		acc: 11,
		eva: 10
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};

var MM3 = [ //Humanoids
					 [/*1-4*/		[Rat, Bat, Spider, Lizard, Snake], 
					 /*6-9*/		[Dog, Boar, Salamander, Fox, Badger],
					 /*11-14*/		[Kobold, Gnome, Goblin, BugbearCub, GnollPup],
					 /*16-19*/		[KoboldWarrior, GnomeWarrior, GoblinShaman, Bugbear, Gnoll],
					 /*21-24*/		[KoboldShaman, GnomeRogue, GoblinMarauder, GreatBugbear, GnollWarrior],
					 /*26-29*/		[KoboldAssassin, GnomeMage, GoblinSoldier, Orc, Ogre],
					 /*31-34*/		[Dwarf, Elf, HumanFighter, HumanMage, HumanRogue],
					 /*36-39*/		[HillDwarf, ElfWarrior, OrcWarrior, GreatOgre, KoboldLord],
					 ],
					 [/*1-4*/		[Haemogoblin, Hobgoblin, ElfMage, DarkElf, DwarfWarrior], 
					 /*6-9*/		[HighElf, Troll, Cyclops, HobgoblinWarrior, Thief],
					 /*11-14*/		[Summoner, CaveTroll, Leprechaun, Angel, HalfOrc],
					 /*16-19*/		[Warlock, TrollShaman, CyclopsWarrior, Knight, Barbarian],
					 /*21-24*/		[DwarfArchitect, MirrorMage, GoblinOozeSlinger, GnomePyromancer, ElfMonk],
					 /*26-29*/		[OneWingedAngel, GnomeBard, HighKnight, ArmoredCyclops, Heretic],
					 /*31-34*/		[SwampTroll, ChaosDruid, ForgottenWarrior, MindFlayer, DragonTrainer],
					 /*36-39*/		[Warlord, MasterAngel, EliteDungeonGuard],
					 ]
				];

//Other Monsters
var EliteDungeonGuard = {
	name: "Elite Dungeon Guard",
	type: "humanoid",
	stats: {
		maxHP: 1,
		HP: 1,
		str: 1,
		acc: 1,
		eva: 1
	},
	drop: "placeholder",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};

var GetChampion = function(){
	if (localStorage.getItem("ThroneFilled") = true){
		var Champion = {
			name: localStorage.getItem("ChampName"),
			type: localStorage.getItem("ChampType"), //Player Race + Class
			stats: {
				maxHP: parseInt(localStorage.getItem("maxHP")),
				HP: parseInt(localStorage.getItem("maxHP")),
				armor: parseInt(localStorage.getItem("armor")),
				str: parseInt(localStorage.getItem("str")),
				mag: parseInt(localStorage.getItem("mag")),
				acc: parseInt(localStorage.getItem("acc")),
				eva: parseInt(localStorage.getItem("eva")),
				luck: parseInt(localStorage.getItem("luck"))
			},
			drop: "Awesome Trophy",
			dropchance: 0,
			attacks: [CEA.normal],
			attackChances: [100]
		};
	};
};
var CrownChampion = function(){
	localStorage.setItem("ChampName", Player.Name);
	localStorage.setItem("ChampType", Player.Race.name + Player.Class.name);
	localStorage.setItem("maxHP", Player.maxHP);
	localStorage.setItem("armor", Player.armor);
	localStorage.setItem("str", Player.str+Player.ext_str);
	localStorage.setItem("mag", Player.mag+Player.ext_mag);
	localStorage.setItem("acc", Player.acc+Player.ext_acc);
	localStorage.setItem("eva", Player.eva+Player.ext_eva);
	localStorage.setItem("luck", Player.luck+Player.ext_luck);
	localStorage.setItem("ThroneFilled", true);
};

var CreateTransformedMonster = function(){
	var NewMonster = new Object();
	
	NewMonster.name = "Transformo";
	NewMonster.type = "monster";
	NewMonster.stats = new Object();
	NewMonster.getInfo = function(){
		var lvl = Math.floor(RoomsCleared/3);
		if (Enemy.weapon.hasOwnProperty("HP")) Enemy.stats.maxHP = Math.ceil((lvl+Enemy.weapon.HP)*1.5);
		else Enemy.stats.maxHP = Math.ceil(lvl*1.5);
		Enemy.stats.HP = Enemy.stats.maxHP;
		if (Enemy.weapon.hasOwnProperty("str")) Enemy.stats.str = (lvl+Enemy.weapon.str);
		else Enemy.stats.str = lvl;
		if (Enemy.weapon.hasOwnProperty("acc")) Enemy.stats.acc = (lvl+Enemy.weapon.acc);
		else Enemy.stats.acc = lvl;
		if (Enemy.weapon.hasOwnProperty("eva")) Enemy.stats.eva = (lvl+Enemy.weapon.eva);
		else Enemy.stats.eva = lvl;
	},
	NewMonster.drop = "";
	NewMonster.dropchance = 0;
	NewMonster.startsWithAVowel = false;
	NewMonster.hitMessage = Weapon.message;
	NewMonster.attacks = [CEA.normal];
	NewMonster.attackChances = [100];
	NewMonster.onHit = function(){};
	
	return NewMonster;
};

//Transform Monsters
var GoldGolem = {
	name: "Gold Golem",
	type: "golem",
	stats: {},
	getInfo: function(){
		//not actually worked out properly
		var lvl = Math.floor(R().number/5) * Floor;
		Enemy.stats.maxHP = Math.ceil(lvl*1.5);
		Enemy.stats.HP = Enemy.stats.maxHP;
		Enemy.stats.str = lvl;
		Enemy.stats.acc = lvl;
		Enemy.stats.eva = lvl;
	},
	drop: "",
	dropchance: 0,
	startsWithAVowel: false,
	specialAttack: function(){}, //optional
	onHit: function(){},
	attacks: [CEA.normal],
	attackChances: [100]
};


