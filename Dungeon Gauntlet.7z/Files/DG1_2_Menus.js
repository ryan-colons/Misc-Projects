var ViewKeyCommands = function(){
	print("<text style='font-size:0.8em'><br>Use <strong>arrow keys</strong> to move around the map.<br>");
	print("Press <strong>1</strong> to see Inventory.<br>");
	print("Press <strong>2</strong> to see Spell Book.<br>");
	print("Press <strong>3</strong> to see Combat Commands.<br>");
	print("Press <strong>0</strong> at any time to view these commands.<br><br></text>");
};

var OpenCharacterCreation = function(){
	$("#charcreation").css('visibility','visible');
	RefreshCCButtons();
};

var RefreshCCButtons = function(){
	$(".CCbutton").unbind();
	$(".CCbutton").hover(function(){
		$(this).css('background-color','yellow');
	}, function(){
		$(this).css('background-color','#bababa');
	});
	
	var RefreshCharInfo = function(){
		$("#NameCreation").empty();
		$("#NameCreation").append("<br><div id='ChooseNameButton' class='button CCbutton'>Change Name</div><br>");
		if (Player.Name != 0) $("#NameCreation").append("Your name is "+Player.Name+".<br>");
		if (Player.Race != 0) $("#NameCreation").append("Your race is "+Player.Race.name+".<br>");
		if (Player.Class != 0) $("#NameCreation").append("Your class is "+Player.Class.name+".<br>");
		RefreshCCButtons();
	};
	
	$("#ChooseNameButton").click(function(){
		var prompt = window.prompt("What is your name?");
		if (prompt != "" && prompt != null){
			if (prompt.length > 15) {
				window.alert("Player name cannot exceed 15 characters. Sorry!");
			} else {
				Player.Name = prompt;
				RefreshCharInfo();
			};
		};
	});
	
	$(".chooseRace").click(function(){
		if (this.id == "ChooseRaceHUMAN"){ 
			Player.Race = R_Human;
			window.alert("You are now playing as a Human. Humans have fairly balanced stats.");
		};
		if (this.id == "ChooseRaceELF"){
			Player.Race = R_Elf;
			window.alert("You are now playing as an Elf. Elves have higher accuracy, but fewer hitpoints.");
		};
		if (this.id == "ChooseRaceDWARF"){
			Player.Race = R_Dwarf;
			window.alert("You are now playing as a Dwarf. Dwarves have high strength and hitpoints, but lower accuracy and evasiveness.");
		};
		if (this.id == "ChooseRaceGNOME"){ 
			Player.Race = R_Gnome;
			window.alert("You are now playing as a Gnome. Gnomes have low hitpoints and accuracy, but higher magic and luck.");
		};
		RefreshCharInfo();
		//bonuses are given at player creation via the RaceBonuses object.
	});
	
	$(".chooseClass").click(function(){
		if (this.id == "ChooseClassFIGHTER"){
			Player.Class = C_Fighter;
			window.alert("You are now playing as a Fighter. Fighters start with a bonus to HP and accuracy.");
		};
		if (this.id == "ChooseClassMAGE"){
			Player.Class = C_Mage;
			window.alert("You are now playing as a Mage. Mages start with a bonus to magic and evasiveness.");
		};
		if (this.id == "ChooseClassMONK"){
			Player.Class = C_Monk;
			window.alert("You are now playing as a Monk. Monks start with a bonus to magic, accuracy and evasiveness.");
		};
		RefreshCharInfo();
	});
	
	$("#CreateCharacter").click(function(){
		if (Player.Name == 0) window.alert("You must choose a name before entering the dungeon.");
		else if (Player.Race == 0) window.alert("You must choose a race before entering the dungeon.");
		else if (Player.Class == 0) window.alert("You must choose a class before entering the dungeon.");
		else {
			var confirm = window.confirm(Player.Name+" the "+Player.Race.name+" "+Player.Class.name+".\nIs this the character you want to play with?");
			if (confirm == true) CreatePlayer();
		};
	});
};

var OpenMainMenu = function(){
	$("#menu").empty();
	$("#menu").append("<div id='console'></div>");
	print("");
	$("#menu").append("<div id='infobox'></div>");
	$("#infobox").append("<div id='statspanel'></div>");
	$("#infobox").append("<div id='descriptionpanel'></div>");
	//statspanel
	RefreshStatsPanel();
	//
};

var RefreshStatsPanel = function(){
	$("#statspanel").empty();
	$("#statspanel").append(TEXT(Player.Name+" the "+Player.Race.name+" "+Player.Class.name+"<br>","U"));			//Name, Race, Class
	$("#statspanel").append("Hitpoints: "+Player.HP+"/"+Player.maxHP+"<br>");										//HP
	$("#statspanel").append("Armor: "+Player.armor+"<br>");															//Armor
	if (Player.ext_str == 0) $("#statspanel").append("Strength: "+Player.str+"<br>");								//Strength
	if (Player.ext_str > 0) $("#statspanel").append("Strength: "+Player.str+" (+"+Player.ext_str+")<br>");
	if (Player.ext_str < 0) $("#statspanel").append("Strength: "+Player.str+" ("+Player.ext_str+")<br>");
	if (Player.ext_mag == 0) $("#statspanel").append("Magic: "+Player.mag+"<br>");									//Magic
	if (Player.ext_mag > 0) $("#statspanel").append("Magic: "+Player.mag+" (+"+Player.ext_mag+")<br>");
	if (Player.ext_mag < 0) $("#statspanel").append("Magic: "+Player.mag+" ("+Player.ext_mag+")<br>");
	if (Player.ext_acc == 0) $("#statspanel").append("Accuracy: "+Player.acc+"<br>");								//Accuracy
	if (Player.ext_acc > 0) $("#statspanel").append("Accuracy: "+Player.acc+" (+"+Player.ext_acc+")<br>");
	if (Player.ext_acc < 0) $("#statspanel").append("Accuracy: "+Player.acc+" ("+Player.ext_acc+")<br>");
	if (Player.ext_eva == 0) $("#statspanel").append("Evasiveness: "+Player.eva+"<br>");							//Evasiveness
	if (Player.ext_eva > 0) $("#statspanel").append("Evasiveness: "+Player.eva+" (+"+Player.ext_eva+")<br>");
	if (Player.ext_eva < 0) $("#statspanel").append("Evasiveness: "+Player.eva+" ("+Player.ext_eva+")<br>");
	if (Player.ext_luck == 0) $("#statspanel").append("Luck: "+Player.luck+"<br>");									//Luck
	if (Player.ext_luck > 0) $("#statspanel").append("Luck: "+Player.luck+" (+"+Player.ext_luck+")<br>");
	if (Player.ext_luck < 0) $("#statspanel").append("Luck: "+Player.luck+" ("+Player.ext_luck+")<br>");
	$("#statspanel").append("Points: "+Player.points+"<br>");														//Points
};

var OpenInventoryMenu = function(){
	$("#menu").append("<div id='inventorypanel'></div>");
	RefreshInventoryMenu();
};

var RefreshInventoryMenu = function(){
	$("#inventorypanel").empty();
	
	$("#inventorypanel").append("<div id='inventory'>"+TEXT("INVENTORY<br>","U")+"</div>");
	$("#inventory").append("<text style='font-size:0.9em'>"+TEXT("Items","U")+"</text><br>");
	for (i=0; i<Inventory.items.length; i++){
		var ItemName = window[Inventory.items[i]].name;
		$("#inventory").append("<div id='"+Inventory.items[i]+"' class='invButton'>"+ItemName+"</div>");
	};
	$("#inventory").append("<text style='font-size:0.9em'>"+TEXT("Equipment","U")+"</text><br>");
	for (i=0; i<Inventory.equipment.length; i++){
		var ItemName = window[Inventory.equipment[i]].name;
		$("#inventory").append("<div id='"+Inventory.equipment[i]+"' class='invButton'>"+ItemName+"</div>");
	};
	$("#inventory").append("<text style='font-size:0.9em'>"+TEXT("Misc","U")+"</text>");
	for (i=0; i<Inventory.misc.length; i++){
		var ItemName = window[Inventory.misc[i]].name;
		$("#inventory").append("<div id='"+Inventory.misc[i]+"' class='invButton'>"+ItemName+"</div>");
	};
	
	$("#inventorypanel").append("<div id='equipped'>"+TEXT("EQUIPPED<br>","U")+"</div>");
	$("#equipped").append("<text style='font-size:0.9em'>"+TEXT("Head","U")+"</text><br>");						//Head
		if (Equipped.head == 0) $("#equipped").append("<div class=EqButton></div>");
		else $("#equipped").append("<div id='"+Equipped.head+"' class=EqButton>"+window[Equipped.head].name+"</div>");
	$("#equipped").append("<text style='font-size:0.9em'>"+TEXT("Torso","U")+"</text><br>");					//Torso
		if (Equipped.torso == 0) $("#equipped").append("<div class=EqButton></div>");
		else $("#equipped").append("<div id='"+Equipped.torso+"' class=EqButton>"+window[Equipped.torso].name+"</div>");
	$("#equipped").append("<text style='font-size:0.9em'>"+TEXT("Legs","U")+"</text><br>");						//Legs
		if (Equipped.legs == 0) $("#equipped").append("<div class=EqButton></div>");
		else $("#equipped").append("<div id='"+Equipped.legs+"' class=EqButton>"+window[Equipped.legs].name+"</div>");
	$("#equipped").append("<text style='font-size:0.9em'>"+TEXT("Misc","U")+"</text><br>");						//Misc
		if (Equipped.misc == 0) $("#equipped").append("<div class=EqButton></div>");
		else $("#equipped").append("<div id='"+Equipped.misc+"' class=EqButton>"+window[Equipped.misc].name+"</div>");
	$("#equipped").append("<text style='font-size:0.9em'>"+TEXT("Weapon","U")+"</text><br>");					//Weapon
		if (Equipped.weapon == 0) $("#equipped").append("<div class=EqButton></div>");
		else $("#equipped").append("<div id='"+Equipped.weapon+"' class=EqButton>"+window[Equipped.weapon].name+"</div>");
		
	RefreshButtons();
};

var OpenSpellMenu = function(){
	$("#menu").append("<div id='spellpanel'></div>");
	$("#spellpanel").append("<div class='pagebutton' id='whtpage'>WHT</div>");
	$("#spellpanel").append("<div class='pagebutton' id='blkpage'>BLK</div>");
	$("#spellpanel").append("<div class='pagebutton' id='bufpage'>BUFF</div>");
	$("#spellpanel").append("<div class='pagebutton' id='trapage'>TRA</div>");
	$("#spellpanel").append("<div class='pagebutton' id='sumpage'>SUMM</div>");
	$("#spellpanel").append("<div class='pagebutton' id='mscpage'>MISC</div>");
	$("#spellpanel").append("<br><br><div id='spellpage'></div>");
	RefreshButtons();
};

var OpenCombatMenu = function(){
	$("#menu").append("<div id='combatpanel'>Combat Commands</div>");
	$("#combatpanel").append("<div class='button combatbutton' id='attack'>Attack</div>");
	if (Equipped.weapon != 0){
		var W = window[Equipped.weapon];
		if (W.hasOwnProperty("specialAttack")){ 
			$("#combatpanel").append("<div class='button combatbutton' id='weaponAttack'>"+W.specialAttack.name+"</div>");
		};
	};
	for (i=0;i<SkillList.length;i++){
		var s = window[SkillList[i]];
		$("#combatpanel").append("<div class='button combatbutton' id='"+SkillList[i]+"'>"+Skills[SkillList[i]].name+"</div>");
	};
	RefreshButtons();
};

var OpenSubShop = function(shopid){
	$(".subshop").css('display','none');
	$("#"+shopid.substring(2)).css('display','inline');
};

var ToggleShopMenu = function(){
	if ($("#shop").css('visibility') == "hidden") $("#shop").css('visibility','visible');
	else $("#shop").css('visibility','hidden');
	$(".subshop").css('display','none');
	RefreshButtons();
};

var RefreshButtons = function(){
	//unbinding
	$(".combatbutton, .TOsubshop, .invButton, .EqButton, .statshopbutton, .pagebutton, .learnspellbutton").unbind();
	$(".whtspell, .blkspell, .bufspell, .traspell, .sumspell, .gemchoice, .equipmentchoice").unbind();
	$(".itemshopstock, .equipmentshopstock, .specialstock").unbind();
	//
	$(".combatbutton").click(function(){
		if (Equipped.weapon != 0) var W = window[Equipped.weapon];
		else var W = Equipped.weapon;
		
		if ((R().type == "combat" || R().type == "boss") && R().cleared == false){
			if (this.id == "attack"){ 
				if (W.hasOwnProperty("attack")) var dmg = W.attack();
				else var dmg = PlayerAttack();
			} else if (this.id == "weaponAttack") var dmg = W.specialAttack.attack();
			else var dmg = Skills[this.id].effect();
			
			var checkEnemyDeath = DamageEnemy(dmg);
			if (checkEnemyDeath == true) return;
			else CombatRound();
		};
	});
	$(".TOsubshop").click(function(){
		OpenSubShop(this.id);
		if (this.id == "TOspecialshop"){ 
			$("#specialshop").empty();
			$("#specialshop").append("<div id='specialshopinfo'></div><div id='specialshopstocklist'></div>");	
			for (i=0;i<R().stock.length;i++){
				var S = SpecialStock[R().stock[i]];
				$("#specialshopstocklist").append("<div class='specialshopstock' id='"+R().stock[i]+"'>"+S.name+"</div>");		
			};
			RefreshButtons();
		};
	});
	$(".statshopbutton").click(function(){
		if (Player.points < 2) window.alert("You do not have enough points for this.");
		else {
			var confirm = window.confirm("Do you wish to pay 2 points for this stat upgrade?\nWARNING: All stats are capped at 20 (except HP, which is capped \
			at 80). Increasing above this limit will have no effect.");
			if (confirm == true){
				Player.points -= 2;
				if (this.id == "HP") BoostIntrinsics("HP",2);
				else BoostIntrinsics(this.id,1);
			};
		};
	});
	$(".statshopbutton").hover(function(){
		$(this).css('background-color','yellow');
	}, function(){
		$(this).css('background-color','#bababa');
	});
	
	$(".itemshopstock").dblclick(function(){
		BuyStock(this.id);
	});
	$(".itemshopstock").hover(function(){
		$(this).css('background-color','yellow');
		$("#itemshopinfo").append(window[this.id.substring(1)].description);
	}, function(){
		$(this).css('background-color','pink');
		$("#itemshopinfo").empty();
	});
	$(".equipmentshopstock").dblclick(function(){
		BuyStock(this.id);
	});
	$(".equipmentshopstock").hover(function(){
		$(this).css('background-color','yellow');
		$("#equipmentshopinfo").append(window[this.id.substring(1)].description);
	}, function(){
		$(this).css('background-color','pink');
		$("#equipmentshopinfo").empty();
	});
	$(".specialshopstock").dblclick(function(){
		SpecialStock[this.id].effect();
	});
	$(".specialshopstock").hover(function(){
		$(this).css('background-color','yellow');
		$("#specialshopinfo").append(SpecialStock[this.id].description);
	}, function(){
		$(this).css('background-color','pink');
		$("#specialshopinfo").empty();
	});
	
	$(".learnspellbutton").hover(function(){
		$(this).css('background-color','yellow');
		$("#spellshopinfo").append("<br><br>"+window[this.id].description);
		$("#spellshopinfo").append("<br><br>"+window[this.id].info);
	}, function(){
		$(this).css('background-color','#bababa');
		$("#spellshopinfo").empty();
	});
	$(".learnspellbutton").click(function(){
		if (window[this.id].level >= 3) window.alert("You have already mastered this spell.");
		else {
			if (Player.points < 2) window.alert("You do not have enough points for this.");
			else {
				var confirm = window.confirm("Do you want to increase your knowledge of this spell? This will cost 2 points.");
				if (confirm == true){
					Player.points -= 2;
					LearnSpell(this.id);
					RefreshStatsPanel();
				};
			};
		};
	});
	$(".invButton, .EqButton").hover(function(){
		$(this).css('background-color','yellow');
		DescribeItem(this.id);
	}, function(){
		$("#descriptionpanel").empty();
		$(this).css('background-color','#bababa');
	});
	$(".invButton").dblclick(function(){
		if (window[this.id].type == "usable") UseItem(this.id);
		if (window[this.id].type == "equipment") EquipItem(this.id);
	});
	$(".EqButton").dblclick(function(){
		UnequipItem(this.id);
	});
	
	$(".pagebutton").hover(function(){
		$(this).css('background-color','yellow');
	}, function(){
		$(this).css('background-color','#575556');
	});
	$(".pagebutton").click(function(){
		$("#spellpage").empty();
		switch(this.id){
		case "whtpage":
			$("#spellpage").append(
			"<div class='whtspell' id='WhtMagic1'><br><strong>Healing Light</strong><br><br>Level "+WhtMagic1.level+"</div>\
			<div class='whtspell' id='WhtMagic2'><br><strong>Steady Restoration</strong><br><br>Level "+WhtMagic2.level+"</div>\
			<div class='whtspell' id='WhtMagic3'><br><strong>Light Ray</strong><br><br><br>Level "+WhtMagic3.level+"</div>\
			<div class='whtspell' id='WhtMagic4'><br><strong>White Aura</strong><br><br><br>Level "+WhtMagic4.level+"</div>\
			<div class='whtspell' id='WhtMagic5'><br><strong>Divine Protection</strong><br><br>Level "+WhtMagic5.level+"</div>"
			);
			break;
		case "blkpage":
			$("#spellpage").append(
			"<div class='blkspell' id='BlkMagic1'><br><strong>Life Drain</strong><br><br><br>Level "+BlkMagic1.level+"</div>\
			<div class='blkspell' id='BlkMagic2'><br><strong>Curse</strong><br><br><br>Level "+BlkMagic2.level+"</div>\
			<div class='blkspell' id='BlkMagic3'><br><strong>Infect</strong><br><br><br>Level "+BlkMagic3.level+"</div>\
			<div class='blkspell' id='BlkMagic4'><br><strong>Harm</strong><br><br><br>Level "+BlkMagic4.level+"</div>\
			<div class='blkspell' id='BlkMagic5'><br><strong>Swarm</strong><br><br>Level "+BlkMagic5.level+"</div>"
			);
			break;
		case "bufpage":
			$("#spellpage").append(
			"<div class='bufspell' id='BufMagic1'><br><strong>Strengthen</strong><br><br><br>Level "+BufMagic1.level+"</div>\
			<div class='bufspell' id='BufMagic2'><br><strong>Focus</strong><br><br><br>Level "+BufMagic2.level+"</div>\
			<div class='bufspell' id='BufMagic3'><br><strong>Quicken</strong><br><br><br>Level "+BufMagic3.level+"</div>\
			<div class='bufspell' id='BufMagic4'><br><strong>Fortune</strong><br><br><br>Level "+BufMagic4.level+"</div>\
			<div class='bufspell' id='BufMagic5'><br><strong>Fortify</strong><br><br>Level "+BufMagic5.level+"</div>"
			);
			break;
		case "trapage":
			$("#spellpage").append(
			"<div class='traspell' id='TraMagic1'><br><strong>Enchant</strong><br><br>Level "+TraMagic1.level+"</div>\
			<div class='traspell' id='TraMagic2'><br><strong>Alchemy</strong><br><br>Level "+TraMagic2.level+"</div>\
			<div class='traspell' id='TraMagic3'><br><strong>Dissolution</strong><br><br>Level "+TraMagic3.level+"</div>"
			
			
			);
			break;
		case "sumpage":
			$("#spellpage").append(
			"<div class='sumspell' id='SumMagic1'><br><strong>Summon Astral Warrior</strong><br><br>Level "+SumMagic1.level+"</div>\
			<div class='sumspell' id='SumMagic2'><br><strong>Summon Astral Guardian</strong><br><br>Level "+SumMagic2.level+"</div>\
			<div class='sumspell' id='SumMagic4'><br><strong>Banish</strong><br><br>Level "+SumMagic4.level+"</div>"
			);
			break;
		case "mscpage":
			break;
		};
		RefreshButtons();
	});
	$(".whtspell, .blkspell, .bufspell, .traspell, .sumspell").hover(
		function(){
			$(this).css('border-width','3px');
			$("#descriptionpanel").empty();
			$("#descriptionpanel").css("font-size","0.7em");
			$("#descriptionpanel").append(window[this.id].description);
		},
		function(){
			$(this).css('border-width','1px');
			$("#descriptionpanel").css("font-size","0.9em");
			$("#descriptionpanel").empty();
		});
		
	$(".whtspell, .blkspell, .bufspell, .traspell, .sumspell").click(function(){
		CastSpell(this.id);
	});
};

var OpenExtraMenu = function(){
	UnbindButtons();
	$("#extramenu").css("visibility","visible");
};
var CloseExtraMenu = function(){
	$(window).unbind("keydown");
	ActivateKeyCommands();
	RefreshButtons();
	$("#extramenu").empty();
	$("#extramenu").css("visibility","hidden");
};
var UnbindButtons = function(){
	$("body").unbind("keydown");
	$(".combatbutton, .TOsubshop, .invButton, .EqButton, .statshopbutton, .pagebutton, .learnspellbutton").unbind();
	$(".whtspell, .blkspell, .bufspell, .traspell, .sumspell, .gemchoice, .equipmentchoice").unbind();
};