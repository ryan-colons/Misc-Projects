//Map

var H = function(element, percentage){
	var h = $(element).height();
	return h * (percentage/100);
};
var W = function(element, percentage){
	var w = $(element).width();
	return w * (percentage/100);
};
var R = function(){
	return RoomArray[PlayerX][PlayerY][0];
};

var ResizeCanvas = function(){
	$("#canvas").attr("width", W(container,64));
	$("#canvas").attr("height", H(container,98));
	$("#shop, #charcreation").css("width", W(container,64));
	$("#shop, #charcreation").css("height", H(container,98));
	$("#extramenu").css("width", W(canvas,80));
	$("#extramenu").css("height", H(canvas,80));
	$("#extramenu").css("margin-top", W(canvas,7.5));
	$("#extramenu").css("margin-left", H(canvas,12.5));
};

var MapSeed = "";

var GetSeed = function(){
	//seed is a 12 digit string, each digit represents the (non-)existence and length of an optional sidepath
	//sidepaths will be up to 3 sections long (i.e. up to 3 reward rooms)
	//sections will have increasingly difficult scaling monsters and increasingly awesome rewards
	//special monsters will give no points
	for (n=0;n<12;n++){
		var Number = RNG(3).toString();
		MapSeed = MapSeed + Number;
	};
};

var PlayerX = 0;
var PlayerY = 15;
var Floor = 1;
var RoomArray = [];

var CreateRoomArray = function(){
	for (x=0;x<40;x++){
		RoomArray.push([]);
		for (y=0;y<30;y++){
			RoomArray[x].push([]);
		};
	};
	FillRoomArray();
};

var FillRoomArray = function(){
	for (x=0;x<40;x++){ 											//outer walls
		for (y=0;y<30;y++){
			if (x==0 || y==0 || x==39 || y==29){	
				var R = new Object();
				R.number = -1;
				R.type = "OuterWall"
				RoomArray[x][y].push(R);
			};
		};
	};
	if (Floor == 1){												//main path Floor 1
		var roomnumber = 1;
		for (x=1;x<=35;x++){
			var R = new Object();
			R.number = roomnumber;
			
			if (x%5 != 0){ 
				R.type = "combat";
				R.monster = ChooseRoomMonster(roomnumber-1);
				R.trap = ChooseRoomTrap();
			} else if (x != 35){ 
				R.type = "shop"
				R.stock = ChooseShopStock();
			} else {
				R.type = "boss";
				R.monster = ChooseRoomBoss();
			};
			R.cleared = false;
			RoomArray[x][15].push(R);
			roomnumber += 1;
		};
		R = new Object();
		R.type = "stairs";
		RoomArray[36][15].push(R);
		roomnumber += 1;
		
		var X = 5;														//north paths
		for (n=0;n<14;n+=2){
			var Y = 14;
			var Q = parseInt(MapSeed.charAt(n)) * 4;
			//MapSeed is 12 numbers from 0 to 3.
			//This looks at the first 6 (n)
			//and turns them into numbers from 0 to 12 (Q).
			for (q=1;q<=Q;q++){
				var R = new Object();
				if (q > 8) R.number = n + "-" + q;
				else if (q > 4) R.number = n + "-" + q;
				else if (q > 0) R.number = n + "-" + q;
				
				if (q%4 == 0){ 
					R.type = "reward";
					R.reward = ChooseRoomReward(R.number);
				} else {
					R.type = "combat";
					R.monster = CreateExtraMonster(R.number);
					R.trap = ChooseRoomTrap();
				};
				R.cleared = false;
				RoomArray[X][Y].push(R);
				Y -= 1;
			};
			X += 5;
		};
		var X = 5;														//south paths
		for (n=1;n<14;n+=2){
			var Y = 16;
			var Q = parseInt(MapSeed.charAt(n)) * 4;
			//MapSeed is 12 numbers from 0 to 3.
			//This looks at the first 6 
			//and turns them into numbers from 0 to 12.
			for (q=1;q<=Q;q++){
				var R = new Object();
				if (q > 8) R.number = n + "-" + q;
				else if (q > 4) R.number = n + "-" + q;
				else if (q > 0) R.number = n + "-" + q;
				
				if (q%4 == 0){ 
					R.type = "reward";
					R.reward = ChooseRoomReward(R.number);
				} else {
					R.type = "combat";
					R.monster = CreateExtraMonster(R.number);
					R.trap = ChooseRoomTrap();
				};
				R.cleared = false;
				RoomArray[X][Y].push(R);
				Y += 1;
			};
			X += 5;
		};
	};
	if (Floor == 2){												//main path Floor 2
		var roomnumber = 36;										//this might be a little dodgey
		R = new Object();
		R.type = "stairs";
		RoomArray[38][15].push(R);
		for (x=37;x>=2;x--){
			var R = new Object();
			R.number = roomnumber;
			if (x == 3){
				R.type = "boss";
				R.monster = ChooseRoomBoss();
			} else if (x == 2){
				R.type = "throne";
			} else if ((x+2)%5 != 0){
				R.type = "combat";
				R.monster = ChooseRoomMonster(roomnumber-35);
				R.trap = ChooseRoomTrap();
			} else {
				R.type = "shop"
				R.stock = ChooseShopStock();
			};
			R.cleared = false;
			RoomArray[x][15].push(R);
			roomnumber += 1;
		};
		var X = 8;														//north paths
		for (n=0;n<14;n+=2){
			var Y = 14;
			var Q = parseInt(MapSeed.charAt(n)) * 4;
			//MapSeed is 12 numbers from 0 to 3.
			//This looks at the first 6 (n)
			//and turns them into numbers from 0 to 12 (Q).
			for (q=1;q<=Q;q++){
				var R = new Object();
				if (q > 8) R.number = n + "-" + q;
				else if (q > 4) R.number = n + "-" + q;
				else if (q > 0) R.number = n + "-" + q;
				
				if (q%4 == 0){ 
					R.type = "reward";
					R.reward = ChooseRoomReward(R.number);
				} else {
					R.type = "combat";
					R.monster = CreateExtraMonster(R.number);
					R.trap = ChooseRoomTrap();
				};
				R.cleared = false;
				RoomArray[X][Y].push(R);
				Y -= 1;
			};
			X += 5;
		};
		var X = 8;														//south paths
		for (n=1;n<14;n+=2){
			var Y = 16;
			var Q = parseInt(MapSeed.charAt(n)) * 4;
			//MapSeed is 12 numbers from 0 to 3.
			//This looks at the first 6 
			//and turns them into numbers from 0 to 12.
			for (q=1;q<=Q;q++){
				var R = new Object();
				if (q > 8) R.number = n + "-" + q;
				else if (q > 4) R.number = n + "-" + q;
				else if (q > 0) R.number = n + "-" + q;
				
				if (q%4 == 0){ 
					R.type = "reward";
					R.reward = ChooseRoomReward(R.number);
				} else {
					R.type = "combat";
					R.monster = CreateExtraMonster(R.number);
					R.trap = ChooseRoomTrap();
				};
				R.cleared = false;
				RoomArray[X][Y].push(R);
				Y += 1;
			};
			X += 5;
		};
	};
};

var DrawMap = function(){
	var canvas = document.getElementById("canvas");
	var context = canvas.getContext("2d");
	var CH = canvas.height;
	var CW = canvas.width;
	var TX = CW / 40;
	var TY = CH / 30;
	context.clearRect(0,0,CW,CH);	
	context.fillStyle = "#575556";
	context.fillRect(0,0,CW,CH);

	for (x=0;x<40;x++){
		for (y=0;y<30;y++){
			if (RoomArray[x][y].length > 0){
				switch(RoomArray[x][y][0].type){
				case "OuterWall":
					context.fillStyle = "black";
					break;
				case "combat":
					context.fillStyle = "white";
					break;
				case "shop":
					context.fillStyle = "blue";
					break;
				case "reward":
					context.fillStyle = "yellow";
					break;
				case "boss":
					context.fillStyle = "purple";
					break;
				case "stairs":
				case "throne":
					context.fillStyle = "orange";
					break;
				};
				context.fillRect(x*TX,y*TY,TX,TY);
			};
		};
	};
	context.fillStyle = "green";									//place player
	context.fillRect(PlayerX*TX, PlayerY*TY, TX, TY);
	
	context.lineWidth = 2;
	//line width doesn't scale very well at the moment
	for (x=0;x<=CW;x+=TX){ 											//vertical grid lines
		context.beginPath();
		context.moveTo(x,0);
		context.lineTo(x,CH);
		context.stroke();
	};
	for (y=0;y<=CH;y+=TY){ 											//horizontal grid lines
		context.beginPath();
		context.moveTo(0,y);
		context.lineTo(CW,y);
		context.stroke();
	};
	
};

var ChooseRoomTrap = function(){
	var L1 = ["Poison", "Thunder", "Terrible", "Rolling", "Bottomless", "Smelly", "Farty", ""];
	var L2 = [" Darts", " Gas", " Bolt", " Death", " Boulder", " Guillotine", " Pit", " Farts"];
	return PICK(L1)+PICK(L2);
};

var ChooseShopStock = function(){
	var stock = [];
	for (n=0;n<1;n++){
		var list = ["example"];
		var x = RNG(list.length-1);
		stock.push(list[x]);
		list.splice(x,1);
	};
	return stock;
};

var SpecialStock = {
	//library of all possible special stock. Must be added to list in ChooseShopStock().
	example: {
		price: 4,
		name: "Example Stock",
		effect: function(){ window.alert("You just bought the example stock!"); },
		description: "<br>This is the example explanation for the example stock.<br><br>Provides information."
	}
};



	