var Player = {
	Name: 0,
	Race: 0,
	Class: 0,
	
	maxHP: 5,		
	HP: 5,
	armor: 0,		
	str: 1,			
	ext_str: 0,
	mag: 0,			
	ext_mag: 0,
	acc: 2,			
	ext_acc: 0,
	eva: 2,			
	ext_eva: 0,
	luck: 0,		
	ext_luck: 0,
	
	points: 0,
	extracasts: 0,
	spellscast: 0
};

var Inventory = {
	equipment: [],
	items: ["HealthPotion"],
	misc: []
};
var Equipped = {
	head: 0,
	torso: 0,
	legs: 0,
	misc: 0,
	weapon: 0
};

var Skills = {					//this is a library of all the possible skills
	ancientPower: {
		name: "Ancient Power",
		effect: function(){
			print("You call up an ancient power. The "+Enemy.name+" is struck.<br>");
			var dmg = Languages.runes*2;
			print("You feel drained.<br>");
			Player.HP -= 10-Languages.runes;
			if (Player.HP <= 0) Player.HP = 1;
			return dmg;
		}
	},
	dwarfCharge: {  //low acc, high str
		name: "Charge",
		effect: function(){
			var dmg = 0;
			var hit = ( Player.acc+Player.ext+acc >= Enemy.stats.eva+RNG(2) || RNG(9)==0);
			//probably change this hit chance
			if (hit==false) print("You charge at the "+Enemy.name+", but miss.<br>");
			else { 
				var dmg = Math.floor((Player.str+Player.ext_str)*1.5);
				if (dmg < Enemy.stats.HP) print("You charge at the "+Enemy.name+", bruising the muscle.<br>");
				else print("You charge at the "+Enemy.name+", jamming the skull through the brain and tearing the brain.<br>");
			};
			return dmg;
		}
	},
	elfStrike: {    //low str, high acc
		name: "Strike",
		effect: function(){
			var hit = (Player.acc+Player.ext_acc+RNG(3) > Enemy.stats.eva);
			var dmg = 0;
			if (hit == false) print("You strike at the "+Enemy.name+", but miss.<br>");
			else {
				print("You strike the "+Enemy.name+".<br>");
				dmg = Math.ceil((Player.str+Player.ext_str)/2);
			};
			return dmg;
		}
	}
};
var SkillList = [];				//this is a list of skills the player has acquired	

var Languages = {
	common: 	10,
	dwarvish:	0,
	elvish:		0,
	runes:		0
};

var CreatePlayer = function(){
	if (Player.Name == "BAM"){ 
		Player.str = 1000;
		Player.acc = 1000;
	};
	Player.Race.StartBonus();
	Player.Class.StartBonus();
	$(".CCbutton").unbind();
	$("#charcreation").css('visibility','hidden');
	OpenMainMenu();
	ViewKeyCommands();
	DrawMap();
	ActivateKeyCommands();
};

//Races//
var R_Human = {
	name: "human",
	StartBonus: function(){
		//balanced stats
		Player.maxHP 	+= 0;
		Player.HP 		+= 0;
		Player.str 		+= 0;
		Player.mag 		+= 0;
		Player.acc 		+= 0;
		Player.eva 		+= 0;
		Player.luck 	+= 0;
	}
};
var R_Elf = {
	name: "elf",
	StartBonus: function(){
		//higher acc, lower HP
		Player.maxHP 	-= 2;
		Player.HP 		-= 2;
		Player.str 		+= 0;
		Player.mag 		+= 0;
		Player.acc 		+= 1;
		Player.eva 		+= 0;
		Player.luck 	+= 0;
		Languages.elvish = 10;
	}
};
var R_Dwarf = {
	name: "dwarf",
	StartBonus: function(){
		//higher str/HP, lower acc/eva
		Player.maxHP 	+= 2;
		Player.HP 		+= 2;
		Player.str 		+= 1;
		Player.mag 		+= 0;
		Player.acc 		-= 1;
		Player.eva 		-= 1;
		Player.luck 	+= 0;
		Languages.dwarvish = 10;
	}
};
var R_Gnome = {
	name: "gnome",
	StartBonus: function(){
		//higher mag/luck, lower HP/acc
		Player.maxHP 	-= 2;
		Player.HP 		-= 2;
		Player.str 		+= 0;
		Player.mag 		+= 1;
		Player.acc 		-= 1;
		Player.eva 		+= 0;
		Player.luck 	+= 1;
		Languages.runes = 2;
	}
};
var R_Slime = {
	name: "slime"
};


//Classes//
var C_Fighter = {
	name: "Fighter",
	StartBonus: function(){
		Player.maxHP += 1;
		Player.HP += 1;
		Player.acc += 2;
	}
};
var C_Mage = {
	name: "Mage",
	StartBonus: function(){
		Player.mag += 2;
		Player.eva += 1;
	}
};
var C_Monk = {
	name: "Monk",
	StartBonus: function(){
		Player.mag += 1;
		Player.acc += 1;
		Player.eva += 1;
	}
};
var C_Heretic = {
	name: "Heretic",
	StartBonus: function(){
		Player.maxHP += 1;
		Player.HP += 1;
		Player.str += 1;
		Player.mag += 1;
		Player.acc += 1;
		Player.eva += 1;
		Player.luck += 1;
		Inventory.items.push("MonkeyPaw");
	}
};

//Variables//
var Status = {
	protection: false
};

var RoomsCleared = 0;

