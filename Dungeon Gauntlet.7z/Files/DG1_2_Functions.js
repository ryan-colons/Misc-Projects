//Functions

var ConsoleContents = "<text style='text-decoration:underline'>Welcome to <strong>Dungeon Gauntlet</strong></text><br>";
var print = function(string){
    ConsoleContents = ConsoleContents + string;
	$("#console").empty();
	$("#console").append(ConsoleContents+"<br>");
	$("#console").scrollTop($("#console")[0].scrollHeight);
};

var RNG = function(x){
    //returns a random number from 0 to x
	//tested, works
	return Math.floor(Math.random()*(x+1));
};
var PICK = function(list){
    //returns a random element from a given list
	//tested, works
	return list[RNG(list.length-1)]
};
var WPICK = function(EL,PL){
	//returns an element from EL selected according to probabilities in PL
	//tested, works
	var RandomNumber = RNG(99);
	for (NumInPL=0; NumInPL < PL.length; NumInPL++){
		var ProbabilityPoint = 0;				
		for (Sum=0; Sum<=NumInPL; Sum++) ProbabilityPoint += PL[Sum];
		if (RandomNumber < ProbabilityPoint) return EL[NumInPL];
	};
	//if PL is longer than EL, the extra PL elements are not used
	//if EL is longer than PL, the extra EL elements will have a probability of zero.
};

var ActivateKeyCommands = function(){
	$("body").unbind("keydown");
	$("body").keydown(function(event){ 
		switch(event.which){
		case 48:
			ViewKeyCommands();
			break;
		case 49:
			OpenMainMenu();
			OpenInventoryMenu();
			break;
		case 50:
			OpenMainMenu();
			OpenSpellMenu();
			break;
		case 51:
			OpenMainMenu();
			OpenCombatMenu();
			break;
		case 52: 
			if (R().type == "shop"){ 
				if (Player.Class == C_Heretic) print("The shop will not open to you.<br>");
				else ToggleShopMenu();
			};
			break;
		case 37:
			if (FindAdjacentRooms().indexOf("west") != -1) MovePlayer(-1,0);
			break;
		case 38:
			if (FindAdjacentRooms().indexOf("north") != -1) MovePlayer(0,-1);
			break;
		case 39:
			if (FindAdjacentRooms().indexOf("east") != -1) MovePlayer(1,0);
			break;
		case 40:
			if (FindAdjacentRooms().indexOf("south") != -1) MovePlayer(0,1);
			break;
		case 13: //enter
			if (R().hasOwnProperty("reward")){
				if (R().reward.Claimed == false) R().reward.Claim();
			} else if (R().type == "stairs" && Floor == 1) DescendStairs();
			break;
		};
	});
};

var FindAdjacentRooms = function(){
	if (PlayerX == 0) return "east";
	var adjacentRooms = [];
	if (RoomArray[PlayerX][PlayerY-1][0] != undefined && RoomArray[PlayerX][PlayerY-1][0] != 0) adjacentRooms.push("north");
	if (RoomArray[PlayerX+1][PlayerY][0] != undefined && RoomArray[PlayerX+1][PlayerY][0] != 0) adjacentRooms.push("east");
	if (RoomArray[PlayerX][PlayerY+1][0] != undefined && RoomArray[PlayerX][PlayerY+1][0] != 0) adjacentRooms.push("south");
	if (RoomArray[PlayerX-1][PlayerY][0] != undefined && RoomArray[PlayerX-1][PlayerY][0] != 0) adjacentRooms.push("west");
	return adjacentRooms;
};

var MovePlayer = function(Mx, My){
	$("#shop").css('visibility','hidden');
	if (R().type == "boss" && R().cleared == false) return;
	if (R().type != "combat" || R().cleared == true){
		PlayerX += Mx;
		PlayerY += My;
		if (R().number == -1){
			PlayerX -= Mx;
			PlayerY -= My;
			DrawMap();
			return;
		};
		if (R().type != "stairs") print("<br>You enter room "+R().number+".<br>");
		DrawMap();
		RoomState();
	};
};

var RoomState = function(){
	T = R().type;
	C = R().cleared;
	switch(T){
	case "combat":
		if (C == false) EnterCombat();
		break;
	case "continuable":
		break;
	case "shop":
		print("A shop is open here. (Press <strong>4</strong> to open/close the shop).<br>");
		break;
	case "reward":
		R().reward.Open();
		break;
	case "boss":
		if (C == false) EnterCombat();
		break;
	case "stairs":
		if (Floor == 1){
			print("There is a staircase leading down. Press <strong>enter</strong> to descend to the next level.");
		} else print("There is a set of stairs leading up. You may not go back.");
		break;
	case "throne":
		if (localStorage.ThroneFilled == false){
			print("You have reached the throne room. Press <strong>enter</strong> to sit on the throne.<br>");
			SitOnThrone();
		};
	};
};

var DescendStairs = function(){
	print("<br>You descend the stairs.<br>");
	PlayerX = 38;
	PlayerY = 15;
	Floor = 2;
	RoomArray = [];
	CreateRoomArray();
	DrawMap();
};
var SitOnThrone = function(){
	print("You take your place on the throne.<br><strong>You are the new Dungeon Champion!</strong><br>");
	print("Click <a href='DG1.2.html'>here</a> to play again.");
	UnbindButtons();
	CrownChampion();
};

var PointGain = function(n){
	if (Inventory.misc.indexOf("DungeonTalisman") != -1) n *= 2;
	Player.points += n;
	RefreshStatsPanel();
};

var BuyStock = function(id){
	var itemid = id.substring(1);
	var price = parseInt(id[0]);
	var item = window[itemid];
	if (Player.points < price){
		window.alert("You do not have enough points for this.");
	} else {
		//should there be a confirm box for purchases?
		Player.points -= price;
		if (item.type == "equipment") Inventory.equipment.push(itemid);
		else if (item.type == "usable") Inventory.items.push(itemid);
		else Inventory.misc.push(itemid);
		print("You spend "+price+" points and acquire the "+item.name+".<br>");
		RefreshInventoryMenu();
		RefreshStatsPanel();
	}
};

var TEXT = function(string, X){
	if (X == "U") return "<font style='text-decoration:underline'>"+string+"</font>";
	else if (X == "B") return "<strong>"+string+"</strong>";
	else if (X == "I") return "<em>"+string+"</em>";
	else return "<font style='color:"+X+"'>"+string+"</font>";
};

var GodMode = function(){
	Player.acc = 100;
	Player.eva = 100;
	Player.str = 100;
	Player.Name = "Cheater";
	return "Booooooom";
};

var Enchant = function(){
	//probably works!
	//can't enchant same item twice
	var g = window[TraMagic1.chosenGem];
	if (g.stats.hasOwnProperty("armor")) g.stats.armor *= TraMagic1.level;
	if (g.stats.hasOwnProperty("str")) g.stats.str *= TraMagic1.level;
	if (g.stats.hasOwnProperty("mag")) g.stats.mag *= TraMagic1.level;
	if (g.stats.hasOwnProperty("acc")) g.stats.acc *= TraMagic1.level;
	if (g.stats.hasOwnProperty("eva")) g.stats.eva *= TraMagic1.level;
	if (g.stats.hasOwnProperty("luck")) g.stats.luck *= TraMagic1.level;
	var e = window[TraMagic1.chosenEquipment];
	window["UniqueEq"+UniqueItemsNo] = new Object();
	n = window["UniqueEq"+UniqueItemsNo];
	//name, type, slot, restrictions, stats, enchantable, EquipMessage, UnequipMessage, SlimeMessage, On(), Off(), description
	n = $.extend(true, n, e);
	n.name = "Enchanted "+e.name;
	n.enchantable = false;
	if (g.stats.hasOwnProperty("armor") && n.stats.hasOwnProperty("armor")) n.stats.armor += g.stats.armor;
	else if (g.stats.hasOwnProperty("armor")) n.stats.armor = g.stats.armor;
	if (g.stats.hasOwnProperty("str") && n.stats.hasOwnProperty("str")) n.stats.str += g.stats.str;
	else if (g.stats.hasOwnProperty("str")) n.stats.str = g.stats.str;
	if (g.stats.hasOwnProperty("mag") && n.stats.hasOwnProperty("mag")) n.stats.mag += g.stats.mag;
	else if (g.stats.hasOwnProperty("mag")) n.stats.mag = g.stats.mag;
	if (g.stats.hasOwnProperty("acc") && n.stats.hasOwnProperty("acc")) n.stats.acc += g.stats.acc;
	else if (g.stats.hasOwnProperty("acc")) n.stats.acc = g.stats.acc;
	if (g.stats.hasOwnProperty("eva") && n.stats.hasOwnProperty("eva")) n.stats.eva += g.stats.eva;
	else if (g.stats.hasOwnProperty("eva")) n.stats.eva = g.stats.eva;
	if (g.stats.hasOwnProperty("luck") && n.stats.hasOwnProperty("luck")) n.stats.luck += g.stats.luck;
	else if (g.stats.hasOwnProperty("luck")) n.stats.luck = g.stats.luck;
	
	n.description = "<br><strong>"+n.name+"</strong><br><br>"																			
	if (n.stats.armor > 0) n.description = n.description + "+"+n.stats.armor+" armor<br>";												
	if (n.stats.armor < 0) n.description = n.description + n.stats.armor+ " armor<br>";													
	if (n.stats.str > 0) n.description = n.description + "+"+n.stats.str+" str<br>";													
	if (n.stats.str < 0) n.description = n.description + n.stats.str+ " str<br>";														
	if (n.stats.mag > 0) n.description = n.description + "+"+n.stats.mag+" mag<br>";													
	if (n.stats.mag < 0) n.description = n.description + n.stats.mag+ " mag<br>";													
	if (n.stats.acc > 0) n.description = n.description + "+"+n.stats.acc+" acc<br>";
	if (n.stats.acc < 0) n.description = n.description + n.stats.acc+ " acc<br>";
	if (n.stats.eva > 0) n.description = n.description + "+"+n.stats.eva+" eva<br>";
	if (n.stats.eva < 0) n.description = n.description + n.stats.eva+ " eva<br>";
	if (n.stats.luck > 0) n.description = n.description + "+"+n.stats.luck+" luck<br>";
	if (n.stats.luck < 0) n.description = n.description + n.stats.luck+ " luck<br>";
	
	print("You enchant the "+e.name+" with the "+g.name+".<br>");
	Inventory.misc.splice(Inventory.misc.indexOf(TraMagic1.chosenGem),1);
	Inventory.equipment.splice(Inventory.equipment.indexOf(TraMagic1.chosenEquipment),1);
	Inventory.equipment.push("UniqueEq"+UniqueItemsNo);
	UniqueItemsNo += 1;
	TraMagic1.chosenGem = 0;
	TraMagic1.chosenEquipment = 0;
};

var Alchemy = function(){
	var g1 = window[TraMagic2.chosenGem];
	var n = TraMagic2.crystal;
	console.log(g1);
	//name, type, stats, value, description
	n.name = "Crystal";
	if (g1.stats.hasOwnProperty("armor")) n.armor += g1.stats.armor*TraMagic2.level;
	if (g1.stats.hasOwnProperty("str")) n.str += g1.stats.str*TraMagic2.level;
	if (g1.stats.hasOwnProperty("mag")) n.mag += g1.stats.mag*TraMagic2.level;
	if (g1.stats.hasOwnProperty("acc")) n.acc += g1.stats.acc*TraMagic2.level;
	if (g1.stats.hasOwnProperty("eva")) n.eva += g1.stats.eva*TraMagic2.level;
	if (g1.stats.hasOwnProperty("luck")) n.luck += g1.stats.luck*TraMagic2.level;
	
	n.description = "<br><strong>"+n.name+"</strong><br><br>"																			
	if (n.armor > 0) n.description = n.description + "+"+n.armor+" armor<br>";												
	if (n.armor < 0) n.description = n.description + n.armor+ " armor<br>";													
	if (n.str > 0) n.description = n.description + "+"+n.str+" str<br>";													
	if (n.str < 0) n.description = n.description + n.str+ " str<br>";														
	if (n.mag > 0) n.description = n.description + "+"+n.mag+" mag<br>";													
	if (n.mag < 0) n.description = n.description + n.mag+ " mag<br>";													
	if (n.acc > 0) n.description = n.description + "+"+n.acc+" acc<br>";
	if (n.acc < 0) n.description = n.description + n.acc+ " acc<br>";
	if (n.eva > 0) n.description = n.description + "+"+n.eva+" eva<br>";
	if (n.eva < 0) n.description = n.description + n.eva+ " eva<br>";
	if (n.luck > 0) n.description = n.description + "+"+n.luck+" luck<br>";
	if (n.luck < 0) n.description = n.description + n.luck+ " luck<br>";
	
	eval("var UniqueGem"+UniqueItemsNo+" = new Object();");
	
	TraMagic2.chosenGem = 0;
	n.nothing = false;
	console.log(TraMagic2.crystal);
	$("#alchemyproduct").empty();
	$("#alchemyproduct").append("New Gem:aaaaaaaa<br><br>");
	$("#alchemyproduct").append(n.description);
	Inventory.misc.splice(Inventory.misc.indexOf(TraMagic2.chosenGem), 1);
	UniqueItemsNo += 1;
	TraMagic2.effect();
};

var TestWPICK = function(){
	var L = ["thing1","thing2"];
	var P = [70,30];
	var count1 = 0;
	var count2 = 0;
	var badcount = 0;
	for (x=0;x<100;x++){
		var q = WPICK(L,P);
		if (q == "thing1") count1 += 1;
		else if (q == "thing2") count2 += 1;
		else badcount += 1;
	};
	console.log(count1+" 1s");
	console.log(count2+" 2s");
	console.log(badcount+" failures")
};

var InCombat = function(){
	if (R().type == "combat" || R().type == "boss"){
		if (R().cleared == false) return true;
	};
	return false;
};



