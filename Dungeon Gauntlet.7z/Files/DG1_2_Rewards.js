//Rewards
var ChooseRoomReward = function(n){
	//takes in a string of the form "x-y"
	//x represents how far through the map the room is - should this influence choice?
	//y represents how far down the extra path the room is - definitely influences choice
	
	//3 tiers of rewards, for the 3 potential levels of extra path
	var i = n.indexOf("-");
	n = n.substring(i+1);
	var n = n/4 - 1; 
	var reward = PICK(RewardIndex[n]);
	var RoomReward = new Object();
	for (e=0; e<reward.prop.length; e++){
		var Rprop = reward.prop[e];
		RoomReward[Rprop] = reward[Rprop];
	};
	return RoomReward;
};

var PotionReward = {
	Claimed: false,
	Open: function(){ 
		if (R().reward.Claimed == false) print("There is a chest here. <text style='font-size:0.8em'>\
												 Press <strong>enter</strong> to open it.</text><br>");
	},
	Claim: function(){
		var List = ["HealthPotion", "MagicPotion", "StrengthPotion"];
		print("You open the chest and take its contents. You acquire:<br>");
		for (n=0; n<2; n++){
			var potion = PICK(List);
			print("&nbsp;&nbsp;<em>"+window[potion].name+"</em><br>");
			Inventory.items.push(potion);
		};
		RefreshInventoryMenu();
		R().reward.Claimed = true;
	},
	prop: ["Claimed", "Open", "Claim"]
};
var CombatItemReward = {
	Claimed: false,
	Open: function(){ 
		if (R().reward.Claimed == false) print("There is a chest here. <text style='font-size:0.8em'>\
												 Press <strong>enter</strong> to open it.</text><br>");
	},
	Claim: function(){
		var List = ["ThrowingKnife", "PoisonDart"];
		print("You open the chest and take its contents. You acquire:<br>");
		for (n=0; n<2; n++){
			var item = PICK(List);
			print("&nbsp;&nbsp;<em>"+window[item].name+"</em><br>");
			Inventory.items.push(item);
		};
		RefreshInventoryMenu();
		R().reward.Claimed = true;
	},
	prop: ["Claimed", "Open", "Claim"]
};
var GemReward = {
	Claimed: false,
	Open: function(){ 
		if (R().reward.Claimed == false) print("There is a chest here. <text style='font-size:0.8em'>\
												 Press <strong>enter</strong> to open it.</text><br>");
	},
	Claim: function(){
		var List = ["StrengthGem","HardGem","MagicGem","PrecisionGem","SpeedGem","LuckyGem"];
		print("You open the chest and take its contents. You acquire:<br>");
		for (n=0; n<2+RNG(1); n++){
			var item = PICK(List);
			print("&nbsp;&nbsp;<em>"+window[item].name+"</em><br>");
			Inventory.misc.push(item);
		};
		RefreshInventoryMenu();
		R().reward.Claimed = true;
	},
	prop: ["Claimed", "Open", "Claim"]
};
var ChestReward = {
	Claimed: false,
	Open: function(){ 
		if (R().reward.Claimed == false) print("There is a chest here. <text style='font-size:0.8em'>\
												 Press <strong>enter</strong> to open it.</text><br>");
	},
	Claim: function(){
		var List = ["HealthPotion","MagicPotion","StrengthPotion","ThrowingKnife","PoisonDart", 
					"StrengthGem","HardGem","MagicGem","PrecisionGem","SpeedGem","LuckyGem"];
		print("You open the chest and take its contents. You acquire:<br>");
		for (n=0; n<3; n++){
			var item = PICK(List);
			print("&nbsp;&nbsp;<em>"+window[item].name+"</em><br>");
			if (window[item].type == "usable") Inventory.items.push(item);
			else if (window[item].type == "gem") Inventory.misc.push(item);
		};
		RefreshInventoryMenu();
		R().reward.Claimed = true;
	},
	prop: ["Claimed", "Open", "Claim"]
};
var PointReward = {
	Claimed: false,
	Open: function(){
		if (R().reward.Claimed == false){
			print("The Dungeon Keeper rewards you for reaching this room. You gain 2 points.<br>");
			PointGain(2);
			R().reward.Claimed = false;
		};
	},
	prop: ["Claimed", "Open"]
};

var MagicFountain = {
	Claimed: false,
	Open: function(){
		if (R().reward.Claimed == false) print("There is a glowing fountain in this room. <text style='font-size:0.8em'>\
												Press <strong>enter</strong> to drink from it.</text><br>");
	},
	Claim: function(){
		print("You drink from the fountain. Your mind opens.<br>");
		Player.mag += 2;
		RefreshStatsPanel();
		R().reward.Claimed = true;
	},
	prop: ["Claimed", "Open", "Claim"]
};
var TranslationReward = {
	Claimed: false,
	Open: function(){ 
		if (R().reward.Claimed == false) print("There is a chest here. <text style='font-size:0.8em'>\
												 Press <strong>enter</strong> to open it.</text><br>");
	},
	Claim: function(){
		var List = ["DwarvishTablet", "ElvishScroll", "RuneCodex"];
		print("You open the chest and take its contents. You acquire:<br>");
		for (n=0; n<2; n++){
			var item = PICK(List);
			print("&nbsp;&nbsp;<em>"+window[item].name+"</em><br>");
			Inventory.items.push(item);
		};
		RefreshInventoryMenu();
		R().reward.Claimed = true;
	},
	prop: ["Claimed", "Open", "Claim"]
};
var EquipmentReward = {
	Claimed: false,
	Open: function(){ 
		if (R().reward.Claimed == false) print("There is a chest here. <text style='font-size:0.8em'>\
												 Press <strong>enter</strong> to open it.</text><br>");
	},
	Claim: function(){
		var List = ["MirrorShield"];
		print("You open the chest and take its contents. You acquire:<br>");
		var item = PICK(List);
		print("&nbsp;&nbsp;<em>"+window[item].name+"</em><br>");
		Inventory.equipment.push(item);
		RefreshInventoryMenu();
		R().reward.Claimed = true;
	},
	prop: ["Claimed", "Open", "Claim"]
};
var CombatMoveTomeReward = {
	Claimed: false,
	Open: function(){ 
		if (R().reward.Claimed == false) print("There is a book here. <text style='font-size:0.8em'>\
												 Press <strong>enter</strong> to take it.</text><br>");
	},
	Claim: function(){
		var tome = PICK(["DwarvishTome", "ElvishTome"]);
		print("You pick up the book.<br>");
		Inventory.items.push(tome);
		RefreshInventoryMenu();
		R().reward.Claimed = true;
	},
	prop: ["Claimed", "Open", "Claim"]
};

var TomeReward = {
	Claimed: false,
	Open: function(){
		if (R().reward.Claimed == false) print("In the center of this room sits a old lecturn with a book on it. <text style='font-size:0.8em'>\
												Press <strong>enter</strong> to take the tome.</text><br>");
	},
	Claim: function(){
		var tome = PICK(["WhiteTome", "BlackTome"]);
		print("You acquire:<br>&nbsp;&nbsp;<em>"+window[tome].name+"</em><br>");
		Inventory.items.push(tome);
		RefreshInventoryMenu();
		R().reward.Claimed = true;
	},
	prop: ["Claimed", "Open", "Claim"]
};
var SlimeRoom = {
	Claimed: false, 
	Open: function(){
		if (R().reward.Claimed == false) print("There is a large tank in this room. Inside the tank is a large metal valve. <text style='font-size:0.8em'>\
												Press <strong>enter</strong> to enter the tank and turn the valve.</text><br>");
	},
	Claim: function(){
		if (Equipped.head!=0 || Equipped.torso!=0 || Equipped.legs!=0 || Equipped.misc!=0 || Equipped.weapon!=0){
			window.alert("You don't want to get your equipment wrecked. Unequip everything before entering the tank.<br>");
			return;
		} else {
			if (Player.Race == R_Slime){
				print("Pipes pour slime all over you. You swell up much larger.<br>");
				Player.maxHP += 10;
				Player.HP += 10;
			} else {
				print("Pipes pour corrosive slime all over you, dissolving your body.<br>");
				print("You are now a Slime.<br>");
				Player.Race = R_Slime;
			};
		};
		RefreshStatsPanel();
		R().reward.Claimed = true;
	},
	prop: ["Claimed", "Open", "Claim"]
};
var AncientPowerReward = {
	Claimed: false,
	Open: function(){
		if (R().reward.Claimed == false) print("In the center of this room is a monolith covered in runes. <text style='font-size:0.8em'>\
												Press <strong>enter</strong> to inspect it.</text><br>");
	},
	Claim: function(){
		if (Languages.runes < 2) print("You cannot understand the runes.<br>");
		else if (Languages.runes < 5) print("You can only recognise a few of the runes.<br>");
		else {
			if (SkillList.indexOf("ancientPower"!=-1)) print("The runes give details about the ancient power you learnt before.<br>");
			else { 
				print("You study the runes and learn an ancient skill.<br>");
				SkillList.push("ancientPower");
				R().reward.Claimed = true;
			};
		};
	},
	prop: ["Claimed", "Open", "Claim"]
};
var LibraryReward = {
	Claimed: false,
	Open: function(){
		if (R().reward.Claimed == false) print("The walls of this room are lined with bookshelves. <text style='font-size:0.8em'>\
												Press <strong>enter</strong> to study.</text><br>");
	},
	Claim: function(){
		print("The books here are all dictionaries. You makes some notes to yourself about the different languages.<br>");
		Languages.common = 10;
		Languages.elvish = 10;
		Languages.dwarvish = 10;
		Languages.runes = 10;
		R().Claimed = true;
	},
	prop: ["Claimed", "Open", "Claim"]
};
var TalismanReward = {
	Claimed: false,
	Open: function(){
		if (R().reward.Claimed == false) print("A friendly Dungeon Guard in this room offers you a special talisman for 5 points. <text style='font-size:0.8em'>\
												Press <strong>enter</strong> to accept the offer.</text><br>");
	},
	Claim: function(){
		if (Player.points < 5) print("You do not have enough points for this deal.<br>");
		else {
			Player.points -= 5;
			Inventory.misc.push("DungeonTalisman");
			print("The guard hands over the talisman and then disappears.<br>");
			RefreshInventoryMenu();
			RefreshStatsPanel();
		};
	},
	prop: ["Claimed", "Open", "Claim"]
};



var RewardIndex = [	[PotionReward, CombatItemReward, GemReward, ChestReward],
					[MagicFountain, TranslationReward, EquipmentReward, CombatMoveTomeReward],	
					[TomeReward, SlimeRoom, AncientPowerReward, LibraryReward, TalismanReward],
];

//REWARD IDEAS
//First Tier
//	Normal items - potions, scrolls, equipment
// 	Points
// 	Room counter buff items
//Second Tier
//	NPCs selling extra special stuff
//	Stat boosts
//	Golem parts
//	Ability learning things (e.g. translation keys)
//	Pieces of something cool
////Third Tier
//	Slime Room
//	Side-quests? Taking on new paths/challenges?
// 	Allies (e.g. Gargoyle)
// 	Skill/Spell books
// 	Pieces of something really cool

//8. Special monsters - mimics, etc

