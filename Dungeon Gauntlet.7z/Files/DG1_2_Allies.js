/*//ALLIES
-attack opponents DONE
-defend player 	- take some damage for you DONE
-increase item drops/point gains etc DONE
-buff the player, debuff opponents

Works like buffs, but have more functions happening at more different times
Tracked with room/round counters
*/

var ActiveAllies = [];
var AlliesAttack = function(){
	for (i=0; i<ActiveAllies.length; i++){
		var ally = window[ActiveAllies[i]];
		if (ally.hasOwnProperty("attack")==true) ally.attack();
		if (Enemy.HP < 0){ 
			return true;
		};
	};
	return false;
};
var AlliesDefend = function(dmg){
	//damage is passed in and modifed by each defender
	//damage is passed out to GetPdmgModifiers and DamagePlayer
	for (i=0; i<ActiveAllies.length; i++){
		var ally = window[ActiveAllies[i]];
		if (ally.hasOwnProperty("defend")==true) dmg = ally.defend(dmg);
		if (dmg <= 0) return 0;
	};
	return dmg;
};
var AlliesGain = function(){
	for (i=0; i<ActiveAllies.length; i++){
		var ally = window[ActiveAllies[i]];
		if (ally.hasOwnProperty("gain")==true) ally.gain();
	};
};
var AlliesBuff = function(){
	for (i=0; i<ActiveAllies.length; i++){
		var ally = window[ActiveAllies[i]];
		if (ally.hasOwnProperty("buff")==true) ally.buff();
	};
	RefreshStatsPanel();
};

var AllyTemplate = {
	join: function(){},
	attack: function(){},	//triggered after the player attacks
	defend: function(){},	//triggered while calculating enemy dmg
	buff: function(){},		//triggered at start of combat
	gain: function(){},		//triggered at end of combat
	leave: function(){}
};

var AstralWarrior = {
	str: 0,
	acc: 0,
	join: function(){
		print("An astral warrior materialises and joins your fight.<br>");
	},
	attack: function(){
		if (AstralWarrior.acc+RNG(4) > Enemy.stats.eva+RNG(4)){
			print("The astral warrior strikes the "+Enemy.name+".<br>");
			Enemy.stats.HP -= AstralWarrior.str;
			//NOTE - this doesn't call Enemy.onHit()
		} else print("The astral warrior misses the "+Enemy.name+".<br>");
	},	
	leave: function(){
		print("The astral warrior disappears.<br>");
	}
};
var AstralGuardian = {
	HP: 0,
	ShieldSize: 0,
	join: function(){
		print("An astral guardian materialises and leaps to your aid.<br>");
	},
	defend: function(dmg){
		print("The astral guardian takes some of the damage for you.<br>");
		dmg -= AstralGuardian.ShieldSize;
		AstralGuardian.HP -= AstralGuardian.ShieldSize;
		if (AstralGuardian.HP <= 0) SummonedAlly.counter = -1;
		return dmg;
	},
	leave: function(){
		print("The astral guardian disappears.<br>");
	}
};





