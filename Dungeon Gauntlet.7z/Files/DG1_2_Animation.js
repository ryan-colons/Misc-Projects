/**************************************************		Animating
//Animating Function
	//get context, variables, etc
	//define function
		//clear canvas
		//redraw all the stuff advanced one frame
		//if animation is not complete then, window.setTimeout(StartOver,0.1);
	//
	//call function
///////////////////////////////////////////////////
**************************************************/

//Art
var PlayerImg = new Image();
PlayerImg.src = "Art/Player.png";
var EnemyImg = new Image();
EnemyImg.src = "Art/Enemy.png";
var BackgroundImg = new Image();
BackgroundImg.src = "Art/Background.png";
//

var CombatScene = function(){
	var canvas = document.getElementById("canvas");
	var context = canvas.getContext("2d");
	context.clearRect(0,0,canvas.width, canvas.height);
	draw("Room");
	draw("Player");
	draw("Enemy");
};
	
var PlayerAttackAnimation = function(){
	var canvas = document.getElementById("canvas");
	var context = canvas.getContext("2d");
	draw('Room');
	draw("Player");
	draw("Enemy");
	var x = W(canvas,15);
	var y = H(canvas,40);
	var z = 50;
	
	var MoveRight = function(){
		context.clearRect(0,0,10000,10000);
		draw('Room');
		draw("Enemy");
		x += 3;
		context.drawImage(PlayerImg,x,y);
		if (x < W(canvas,25)) window.setTimeout(MoveRight,1);
		else MoveLeft();
	};
	var MoveLeft = function(){
		context.clearRect(0,0,10000,10000);
		draw('Room');
		draw("Enemy");
		x -= 3;
		context.drawImage(PlayerImg,x,y);
		if (x > W(canvas,15)) window.setTimeout(MoveLeft,1);
	};
	var EnemyShudder = function(){
		context.clearRect(0,0,10000,10000);
		draw('Room');
		draw("Player");
		if (z%4 == 0) draw("Enemy");
		z -= 1;
		if (z > 0) window.setTimeout(EnemyShudder,1);
		else draw("Enemy");
	};
	MoveRight();
	window.setTimeout(EnemyShudder,500);
	window.setTimeout(EnemyAttackAnimaton,1000);
};

var EnemyAttackAnimation = function(){
	var canvas = document.getElementById("canvas");
	var context = canvas.getContext("2d");
	draw('Room');
	draw("Player");
	draw("Enemy");
	var x = W(canvas,80);
	var y = H(canvas,40);
	var z = 50;
	
	var MoveLeft = function(){
		context.clearRect(0,0,10000,10000);
		draw('Room');
		draw("Player");
		x -= 3;
		context.drawImage(EnemyImg,x,y);
		if (x > W(canvas,70)) window.setTimeout(MoveLeft,1);
		else MoveRight();
	};
	var MoveRight = function(){
		context.clearRect(0,0,10000,10000);
		draw('Room');
		draw("Player");
		x += 3;
		context.drawImage(EnemyImg,x,y);
		if (x < W(canvas,80)) window.setTimeout(MoveRight,1);
	};
	var PlayerShudder = function(){
		context.clearRect(0,0,10000,10000);
		draw('Room');
		draw("Enemy");
		if (z%4 == 0) draw("Player");
		z -= 1;
		if (z > 0) window.setTimeout(PlayerShudder,1);
		else draw("Player");
	};
	MoveLeft();
	window.setTimeout(PlayerShudder,500);
};

$(document).ready(function(){
	$("#PlayerAttack").click(function(){
		CloseMenu();
		PlayerAttackAnimation();
		window.setTimeout(EnemyAttackAnimation,1500);
		window.setTimeout(OpenMenu,2000);
	});
});	

var draw = function(image){
	var canvas = document.getElementById("canvas");
	var context = canvas.getContext("2d");
	if (image == "Player"){ 
		while (PlayerImg.height < canvas.height*0.25){
			PlayerImg.height = PlayerImg.height * 1.1;
			PlayerImg.width = PlayerImg.width * 1.1;
		};
		context.drawImage(PlayerImg, canvas.width*0.1, canvas.height*0.5, PlayerImg.width, PlayerImg.height);
	};
	if (image == "Enemy"){ 
		while (EnemyImg.height < canvas.height*0.25){
			EnemyImg.height = EnemyImg.height * 1.1;
			EnemyImg.width = EnemyImg.width * 1.1;
		};
		context.drawImage(EnemyImg, canvas.width*0.7, canvas.height*0.5, EnemyImg.width, EnemyImg.height);
	};
	if (image == "Room"){
		context.clearRect(0,0,800,600);
		context.drawImage(BackgroundImg, 0, 0, canvas.width, canvas.height);
	};
};

var FadeToBlack = function(){
	var canvas = document.getElementById("canvas");
	var context = canvas.getContext("2d");
	var C = context.getImageData(0,0,canvas.width,canvas.height);
	console.log(C.data);
	var blackout = function(x){
		if (x < 10) console.log("doing!");
		C.data[x] = 0;
		DrawMap();
	};
	for (x=0; x<C.data.length; x++){
		if (x < 10) console.log("going!");
		window.setTimeout(blackout(x),0.001);
	};
};


