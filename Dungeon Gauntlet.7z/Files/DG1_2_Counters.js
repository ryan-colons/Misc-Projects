var RoundCounters = [];
var RoomCounters = [];

var AddRoundCounter = function(name,duration){
	//name should be a string, duration should be an integer
	if (RoundCounters.indexOf(name) == -1){	
		RoundCounters.push(name);
		window[name].On();
		window[name].counter = duration;
	} else window[name].counter += duration;
};
var AddRoomCounter = function(name,duration){
	//name should be a string, duration should be an integer
	if (RoomCounters.indexOf(name) == -1){	
		RoomCounters.push(name);
		window[name].On();
		window[name].counter = duration;
	} else window[name].counter += duration;
};

var RoundTick = function(){
	//maybe works!
	for (i=0; i<RoundCounters.length; i++){
		var buff = window[RoundCounters[i]];
		buff.counter -= 1;
		if (buff.counter > 0) buff.WhileOn();
		else {
			buff.Off();
			RoundCounters.splice(i,1);
		};
	};
};
var RoomTick = function(){
	//maybe works!
	for (i=0; i<RoundCounters.length; i++){
		var buff = window[RoundCounters[i]];
		buff.counter = 0;
		buff.Off();
		RoundCounters.splice(i,1);
	};
	for (i=0; i<RoomCounters.length; i++){
		var buff = window[RoomCounters[i]];
		buff.counter -= 1;
		if (buff.counter > 0) buff.WhileOn();
		else {
			buff.Off();
			RoomCounters.splice(i,1);
		};
	};
}; 

var BuffTemplate = {
	counter: 0,
	//optional extras
	On: function(){},
	WhileOn: function(){},
	Off: function(){}
};

var CurseDebuff = {
	counter: 0,
	str: 0,
	acc: 0,
	eva: 0,
	On: function(){
		Enemy.stats.str -= CurseDebuff.str;
		Enemy.stats.acc -= CurseDebuff.acc;
		Enemy.stats.eva -= CurseDebuff.eva;
	},
	WhileOn: function(){},
	Off: function(){
		if (Enemy.stats.HP > 0){
			print("The "+Enemy.name+" recovers from the curse.<br>");
			Enemy.stats.str += CurseDebuff.str;
			Enemy.stats.acc += CurseDebuff.acc;
			Enemy.stats.eva += CurseDebuff.eva;
		};
	}
};
var DebuffPlayerSTR = {
	counter: 0,
	debuff: 0,
	On: function(){
		Player.ext_str -= DebuffPlayerSTR.debuff;
	},
	WhileOn: function(){},
	Off: function(){
		Player.ext_str += DebuffPlayerSTR.debuff;
	}
};
var DivineProtectionBuff = {
	counter: 0,
	magnitude: 0,
	On: function(){
		Player.armor += DivineProtectionBuff.magnitude;
		Status.protection = true;
	},
	WhileOn: function(){},
	Off: function(){
		Player.armor -= DivineProtectionBuff.magnitude;
		Status.protection = false;
	}
};
var FocusBuff = {
	counter: 0,
	magnitude: 0,
	On: function(){
		Player.ext_acc += FocusBuff.magnitude;
	},
	WhileOn: function(){},
	Off: function(){
		print("The focus spell wears off.");
		Player.ext_acc -= FocusBuff.magnitude;
	}
};
var FortuneBuff = {
	counter: 0,
	magnitude: 0,
	On: function(){
		Player.ext_luck += FortuneBuff.magnitude;
	},
	WhileOn: function(){},
	Off: function(){
		print("The luck spell wears off.");
		Player.ext_luck -= FortuneBuff.magnitude;
	}
};
var FortuneBuff = {
	counter: 0,
	magnitude: 0,
	On: function(){
		Player.armor += FortifyBuff.magnitude;
	},
	WhileOn: function(){},
	Off: function(){
		print("The fortification spell wears off.");
		Player.armor -= FortifyBuff.magnitude;
	}
};
var Infection = {
	counter: 0,
	magnitude: 0,
	On: function(){},
	WhileOn: function(){
		print("The "+Enemy.name+" takes damage from the infection.<br>");
		DamageEnemy(Infection.magnitude);
	},
	Off: function(){
		if (Enemy.stats.HP > 0) print("The "+Enemy.name+" recovers from the infection.<br>");
	}
};
var PlayerPoison = {
	counter: 0,
	On: function(){},
	WhileOn: function(){
		print(TEXT("You are hurt by poison.<br>","green"));
		DamagePlayer(Math.ceil(Player.maxHP/10));
	},
	Off: function(){
		print("The poison wears off.<br>");
	}
};
var PoisonDartBuff = {
	counter: 0,
	On: function(){},
	WhileOn: function(){
		print("The "+Enemy.name+" is hurt by the dart's poison.<br>");
		DamageEnemy(1);
	},
	Off: function(){
		if (Enemy.stats.HP > 0) print("The "+Enemy.name+" recovers from the dart's poison.<br>");
	}
};
var SteadyRestorationBuff = {
	counter: 0,
	On: function(){},
	WhileOn: function(){
		print("The white glow shimmers.<br>");
		Player.HP += RNG(1)+2; //restore 2-3 HP
		if (Player.HP > Player.maxHP) Player.HP = Player.maxHP;
	},
	Off: function(){
		print("The white glow fades away.<br>");
	}
};
var StrengthenBuff = {
	counter: 0,
	magnitude: 0,
	On: function(){
		Player.ext_str += StrengthenBuff.magnitude;
	},
	WhileOn: function(){},
	Off: function(){
		print("The strength spell wears off.");
		Player.ext_str -= StrengthenBuff.magnitude;
	}
};
var StrengthPotionBuff = {
	counter: 0,
	On: function(){ Player.ext_str += 2; },
	WhileOn: function(){},
	Off: function(){ Player.ext_str -= 2; }
}
var SummonedAlly = {
	counter: 0,
	ally: 0,
	On: function(){
		window[SummonedAlly.ally].join();
	},
	WhileOn: function(){},
	Off: function(){
		window[SummonedAlly.ally].leave();
		ActiveAllies.splice(ActiveAllies.indexOf(SummonedAlly.ally),1);
		SummonedAlly.ally = 0;
	}
};
var QuickenBuff = {
	counter: 0,
	magnitude: 0,
	On: function(){
		Player.ext_eva += QuickenBuff.magnitude;
	},
	WhileOn: function(){},
	Off: function(){
		print("The agility spell wears off.");
		Player.ext_eva -= QuickenBuff.magnitude;
	}
};
var WhiteAuraBuff = {
	counter: 0,
	magnitude: 0,
	On: function(){
		Player.maxHP += WhiteAuraBuff.magnitude;
	},
	WhileOn: function(){},
	Off: function(){
		Player.maxHP -= WhiteAuraBuff.magnitude;
	}
};

var MonkeyPawCounter = {
	counter: 0,
	On: function(){},
	WhileOn: function(){},
	Off: function(){
		print("<em>The monkey paw raises three fingers.<br></em>");
		MonkeyPaw.fingers = 3;
		MonkeyPaw.description = "<br><strong>Monkey Paw</strong><br><br><em>An old monkey paw. It holds up "+MonkeyPaw.fingers+" fingers.</em>\
								 <br><br>Grants wishes";
	}
};

var MonkeyWish = function(){
	OpenExtraMenu();
	$("#extramenu").append("<div id='wishselection'>Wish For:</div>");
	$("#wishselection").append("<div class='wishchoice'>Health</div>");
	$("#wishselection").append("<div class='wishchoice'>Protection</div>");
	$("#wishselection").append("<div class='wishchoice'>Strength</div>");
	$("#wishselection").append("<div class='wishchoice'>Wisdom</div>");
	$("#wishselection").append("<div class='wishchoice'>Precision</div>");
	$("#wishselection").append("<div class='wishchoice'>Speed</div>");
	$("#wishselection").append("<div class='wishchoice'>Luck</div>");
	CloseExtraMenu();
};







