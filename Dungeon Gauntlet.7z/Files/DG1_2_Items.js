//Items
//Use types: 0 -anywhere, 1 -not in combat; 2 -only in combat; 3 -only in shops
var UniqueItemsNo = 0;
var DescribeItem = function(itemid){
	if (itemid == "") return;
	item = window[itemid];
	$("#descriptionpanel").empty();
	$("#descriptionpanel").append(item.description);
};

var UseItem = function(itemid){
	var item = window[itemid];
	var Use = item.use;
	if (Use==1 && InCombat()==true){
		window.alert("You cannot use this item while in combat.");
		return;
	};
	if (Use==2 && InCombat()==false){
		window.alert("This item is only usable in combat.");
		return;
	};
	if (Use==3 && R().type!="shop"){
		window.alert("This item is only usable in shops.");
		return;
	};
	item.effect();
	if (item.DOU == true){
		var index = Inventory.items.indexOf(itemid);
		Inventory.items.splice(index,1);
	};
	RefreshStatsPanel();
	RefreshInventoryMenu();
};

//name, type, use, DOU, value, description, effect
var BlackTome = {
	name: "Black Tome",
	type: "usable",
	use: 1,
	DOU: true,
	value: 2,
	description: "<br><strong>Black Tome</strong><br><br><em>An old tome. It holds the secrets of black magic.</em><br><br>",
	effect: function(){
		if (BlkMagic1.level>2 && BlkMagic2.level>2 && BlkMagic3.level>2 && BlkMagic4.level>2 /*&& BlkMagic5.level>2*/){
			print("The tome teaches you nothing new. You throw it away.<br>");
		} else {
			print("You read the tome and learn a lot about black magic.<br>");
			if (BlkMagic1.level < 3) BlkMagic1.level += 1;
			if (BlkMagic2.level < 3) BlkMagic2.level += 1;
			if (BlkMagic3.level < 3) BlkMagic3.level += 1;
			if (BlkMagic4.level < 3) BlkMagic4.level += 1;
			//if (WhtMagic5.level < 3) BlkMagic5.level += 1;
		};
	}
};
var DwarvishTablet = {
	name: "Dwarvish Tablet",
	type: "usable",
	use: 1,
	DOU: true,
	value: 2,
	description: "<br><strong>Dwarvish Tablet</strong><br><br><em>A stone tablet engraved with drawings and words in the Dwarvish language.</em><br><br>",
	effect: function(){
		if (Languages.dwarvish < 10){	
			print("You inspect the tablet and manage to pick up a bit of the Dwarvish language.<br>");
			Languages.dwarvish += 2;
		} else print("You inspect the tablet. You understand it perfectly.<br>");
	}
};
var DwarvishTome = {
	name: "Dwarvish Tome",
	type: "usable",
	use: 1,
	DOU: false,
	value: 3,
	description: "<br><strong>Dwarvish Tome</strong><br><br><em>A tome written by dwarves. There is a picture of an axe on the front.</em><br><br>",
	effect: function(){
		switch(Languages.dwarvish){
		case 0: 
			print("The tome is written in dwarvish. You cannot understand it.<br>");
			break;
		case 1:
		case 2:
		case 3:
			print("You recognise some of the writing in the tome, but cannot understand it.<br>");
			break;
		case 4:
		case 5:
		case 6:
		case 7:
			print("You read the tome and learn some new fighting techniques.<br>");
			Player.str += Math.floor(Languages.dwarvish/2);
			print("There is an extra section that you fail to comprehend before the tome falls apart.<br>");
			Inventory.items.splice(Inventory.items.indexOf("DwarvishTome"),1);
			break;
		case 8:
		case 9:
		case 10:
			print("You read the tome and learn some new fighting techniques.<br>");
			Player.str += 3;
			if (SkillList.indexOf("dwarfCharge") == -1){
				print("You also pick up a new combat move.<br>");
				SkillList.push("dwarfCharge");
			};
			Inventory.items.splice(Inventory.items.indexOf("DwarvishTome"),1);
		};
	}
};
var ElvishScroll = {
	name: "Elvish Scroll",
	type: "usable",
	use: 1,
	DOU: true,
	value: 2,
	description: "<br><strong>Elvish Scroll</strong><br><br><em>A piece of parchment covered in pictograms and Elvish script.</em><br><br>",
	effect: function(){
		if (Languages.elvish < 10){	
			print("You inspect the scroll and manage to pick up a bit of the Elvish language.<br>");
			Languages.elvish += 2;
		} else print("You inspect the scroll. You understand it perfectly.<br>");
	}
};
var ElvishTome = {
	name: "Elvish Tome",
	type: "usable",
	use: 1,
	DOU: false,
	value: 3,
	description: "<br><strong>Elvish Tome</strong><br><br><em>A tome written by elves. There is a picture of a sword on the front.</em><br><br>",
	effect: function(){
		switch(Languages.elvish){
		case 0: 
			print("The tome is written in elvish. You cannot understand it.<br>");
			break;
		case 1:
		case 2:
		case 3:
			print("You recognise some of the writing in the tome, but cannot understand it.<br>");
			break;
		case 4:
		case 5:
		case 6:
		case 7:
			print("You read the tome and learn some new fighting techniques.<br>");
			Player.acc += Math.floor(Languages.elvish/2);
			print("There is an extra section that you fail to comprehend before the tome falls apart.<br>");
			Inventory.items.splice(Inventory.items.indexOf("ElvishTome"),1);
			break;
		case 8:
		case 9:
		case 10:
			print("You read the tome and learn some new fighting techniques.<br>");
			Player.acc += 3;
			if (SkillList.indexOf("elfStrike") == -1){
				print("You also pick up a new combat move.<br>");
				SkillList.push("elfStrike");
			};
			Inventory.items.splice(Inventory.items.indexOf("ElvishTome"),1);
		};
	}
};
var GemBag = {
	name: "GemBag",
	type: "usable",
	use: 0,
	DOU: false,
	value: 2,
	description: "<br><strong>Gem Bag</strong><br><br><em>A small bag of gems.</em><br><br>",
	effect: function(){
		var List = ["StrengthGem"];
		print("You open the bag and take its contents. You acquire:<br>");
		for (n=0; n<2; n++){
			var item = PICK(List);
			print("&nbsp;&nbsp;<em>"+window[item].name+"</em><br>");
			Inventory.misc.push(item);
		};
		Inventory.items.splice(Inventory.items.indexOf("GemBag"), 1);
		RefreshInventoryMenu();
		
	}
};
var HealthPotion = {
	name: "Health Potion",
	type: "usable",
	use: 2,
	DOU: false,
	value: 1,
	description: "<br><strong>Health Potion</strong><br><br><em>A restorative elixir.</em><br><br>Usable only in combat.<br>Restores all HP.",
	effect: function(){
		if (Player.HP < Player.maxHP){
			print("You drink the potion. It makes you feel much better.<br>");
			Player.HP = Player.maxHP;
			var index = Inventory.items.indexOf('HealthPotion');
			Inventory.items.splice(index,1);
		} else {
			
		};
	}
};
var MagicPotion = {
	name: "Magic Potion",
	type: "usable",
	use: 2,
	DOU: true,
	value: 1,
	description: "<br><strong>Magic Potion</strong><br><br><em>A magical elixir.</em><br><br>Usable only in combat.<br>Lets you cast more spells.",
	effect: function(){
		Player.spellscast -= 5;
	}
};
var MonkeyPaw = {
	name: "Monkey Paw",
	type: "usable",
	use: 0,
	DOU: false,
	value: 10,
	description: "<br><strong>Monkey Paw</strong><br><br><em>An old monkey paw. It holds up 3 fingers.</em><br><br>Grants wishes",
	effect: function(){
		if (MonkeyPaw.fingers <= 0){
			print("You try to make a wish on the monkey paw, but nothing happens.");
		} else {
			print("<em>The paw lowers a finger.<br></em>");
			MonkeyPaw.fingers -= 1;
			MonkeyPaw.description = "<br><strong>Monkey Paw</strong><br><br><em>An old monkey paw. It holds up "+MonkeyPaw.fingers+" fingers.</em>\
									 <br><br>Grants wishes";
			if (MonkeyPaw.fingers == 0) AddRoomCounter("MonkeyPawCounter",10);
		};
	},
	fingers: 3
};
var PoisonDart = {
	name: "Poison Dart",
	type: "usable",
	use: 2,
	DOU: true,
	value: 1,
	description: "<br><strong>Poison Dart</strong><br><br><em>A small dart dipped in poison.</em><br><br>Usable only in combat.<br>Destroyed on use.",
	effect: function(){
		AddRoundCounter("PoisonDartBuff",3);
		print("You throw the dart at the "+Enemy.name+".<br>");
	}
};
var RuneCodex = {
	name: "Rune Codex",
	type: "usable",
	use: 1,
	DOU: true,
	value: 2,
	description: "<br><strong>Rune Codex</strong><br><br><em>A small codex filled with runes.</em><br><br>",
	effect: function(){
		if (Languages.runes < 10){	
			print("You inspect the codex and manage to learn a few runes.<br>");
			Languages.runes += 2;
		} else print("You inspect the codex. You understand it perfectly.<br>");
	}
};
var StrengthPotion = {
	name: "Strength Potion",
	type: "usable",
	use: 2,
	DOU: true,
	value: 1,
	description: "<br><strong>Strength Potion</strong><br><br><em>A small dagger for throwing.</em><br><br>Usable only in combat.<br>Destroyed on use.",
	effect: function(){
		AddRoundCounter("StrengthPotionBuff",4);
		print("You drink the potion. You feel strong.<br>");
	}
};
var ThrowingKnife = {
	name: "Throwing Knife",
	type: "usable",
	use: 2,
	DOU: true,
	value: 1,
	description: "<br><strong>Throwing Knife</strong><br><br><em>A small dagger for throwing.</em><br><br>Usable only in combat.<br>Destroyed on use.",
	effect: function(){
		//does not take a round of combat
		print("You throw the knife at the "+Enemy.name+".<br>");
		DamageEnemy(3);
	}
};
var WhiteTome = {
	name: "White Tome",
	type: "usable",
	use: 1,
	DOU: true,
	value: 2,
	description: "<br><strong>White Tome</strong><br><br><em>An old tome. It holds the secrets of white magic.</em><br><br>",
	effect: function(){
		if (WhtMagic1.level>2 && WhtMagic2.level>2 && WhtMagic3.level>2 && WhtMagic4.level>2 && WhtMagic5.level>2){
			print("The tome teaches you nothing new. You throw it away.<br>");
		} else {
			print("You read the tome and learn a lot about white magic.<br>");
			if (WhtMagic1.level < 3) WhtMagic1.level += 1;
			if (WhtMagic2.level < 3) WhtMagic2.level += 1;
			if (WhtMagic3.level < 3) WhtMagic3.level += 1;
			if (WhtMagic4.level < 3) WhtMagic4.level += 1;
			if (WhtMagic5.level < 3) WhtMagic5.level += 1;
		};
	}
};

//MISC
var StrengthGem = {
	name: "Strength Gem",
	type: "gem",
	stats: {
		str: 1
	},
	value: 1,
	description: "<br><strong>Strength Gem</strong><br><br><em>A small white gem magically imbued with Strength.</em><br><br>",
};
var HardGem = {
	name: "Hard Gem",
	type: "gem",
	stats: {
		armor: 1
	},
	value: 1,
	description: "<br><strong>Hard Gem</strong><br><br><em>A very hard gem magically imbued with protection.</em><br><br>",
};
var MagicGem = {
	name: "Magic Gem",
	type: "gem",
	stats: {
		mag: 1
	},
	value: 1,
	description: "<br><strong>Strength Gem</strong><br><br><em>A small purple gem imbued with Magic.</em><br><br>",
};
var PrecisionGem = {
	name: "Precision Gem",
	type: "gem",
	stats: {
		acc: 1
	},
	value: 1,
	description: "<br><strong>Precision Gem</strong><br><br><em>A small clear gem magically imbued with Accuracy.</em><br><br>",
};
var SpeedGem = {
	name: "Strength Gem",
	type: "gem",
	stats: {
		eva: 1
	},
	value: 1,
	description: "<br><strong>Speed Gem</strong><br><br><em>A very light gem magically imbued with Evasiveness.</em><br><br>",
};
var LuckyGem = {
	name: "Lucky Gem",
	type: "gem",
	stats: {
		str: 1
	},
	value: 1,
	description: "<br><strong>Lucky Gem</strong><br><br><em>A small golden gem magically imbued with Luck.</em><br><br>",
};

var DungeonTalisman = {
	name: "Dungeon Talisman",
	type: "misc",
	value: 10,
	description: "<br><strong>Dungeon Talisman</strong><br><br><em>A shiny gold figurine.</em><br><br>Doubles all point gains",
};




