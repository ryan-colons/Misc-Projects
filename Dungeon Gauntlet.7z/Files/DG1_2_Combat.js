var Enemy = new Object();
var EnemyIsStunned = false;

var EnterCombat = function(){
	Player.spellscast = 0;
	Enemy = R().monster;
	if (R().monster.hasOwnProperty("getInfo")) Enemy.getInfo();
	if (Enemy.startsWithAVowel == false) print("You are fighting a "+Enemy.name+"<br>");
	else print("You are fighting an "+Enemy.name+"<br>");
	AlliesBuff();
	//CombatScene();
};

var PlayerAttack = function(){
	//PlayerAttackAnimation();
	var dmg = 0;
	if (Equipped.weapon != 0) var W = window[Equipped.weapon];
	else var W = Equipped.weapon;
	if (Player.acc+Player.ext_acc+RNG(Player.luck)+(RNG(4)-2) >= Enemy.stats.eva+(RNG(4)-2) || RNG(9)==0){
	    //you hit!
		if (W.hasOwnProperty("hit")) dmg = W.hit();
		else {
			print("You hit the "+Enemy.name+".<br>");
			dmg = Player.str+Player.ext_str;
		};
	} else {
	    //you miss..
		if (W.hasOwnProperty("miss")) dmg = W.miss();
		else print("You miss the "+Enemy.name+".<br>");
	};
	//this function outputs a number (dmg), to be passed to DamageEnemy()
	return dmg;
};

var DamageEnemy = function(dmg){
	Enemy.stats.HP -= dmg;
	if (dmg > 0) Enemy.onHit(dmg);
	if (Enemy.stats.HP <= 0){ 
		DefeatEnemy();
		return true;
	} else return false;
};
var DefeatEnemy = function(){
	print("The "+Enemy.name+" is killed!<br>");
	R().cleared = true;
	if (Enemy.type != "Dungeon Guard") PointGain(1);
	RoomsCleared += 1;
	AlliesGain();
	Player.HP = Player.maxHP;
	EnemyItemDrop();
	RoomTick();
	RefreshStatsPanel();
};

var EnemyItemDrop = function(){
	var n = RNG(19)+1;
	if (n <= Enemy.dropchance){
		var item = Enemy.drop;
		var type = item.type;
		print("You acquire: "+item.name+"<br>");
		if (type == "usable") Inventory.items.push(item);
		if (type == "equipment") Inventory.equipment.push(item);
		if (type == "misc") Inventory.misc.push(item);
	};
};

var GetPdmgModifiers = function(){
	var Mod = 0;
	Mod -= Player.armor;
	for (i=0;i<PdmgModifiers.length;i++){
		PdmgModifiers(Mod);
	};
	return Mod;
};

var DamagePlayer = function(Pdmg){
	if (Pdmg <= 0 && Status.protection == false) Pdmg = 1;
	else if (Pdmg <= 0) Pdmg = 0;
	Player.HP -= Pdmg;
	
	//Player.onHit(Pdmg);	???
	if (Player.HP <= 0){
		DefeatPlayer();
		return true;
	} else {
		if (Equipped.head != 0) if (window[Equipped.head].hasOwnProperty("onHit")) window[Equipped.head].onHit(Pdmg);
		if (Equipped.torso != 0) if (window[Equipped.torso].hasOwnProperty("onHit")) window[Equipped.torso].onHit(Pdmg);
		if (Equipped.legs != 0) if (window[Equipped.legs].hasOwnProperty("onHit")) window[Equipped.legs].onHit(Pdmg);
		if (Equipped.misc != 0) if (window[Equipped.misc].hasOwnProperty("onHit")) window[Equipped.misc].onHit(Pdmg);
		return false;
	};
};
var DefeatPlayer = function(){
	$("*").unbind();
	RefreshStatsPanel();
	print(TEXT("You have been defeated.<br>","B"));
	print("Click <a href='DG1.2.html'>here</a> to play again.");
};

var CombatRound = function(){
	//3. Summons etc take effect: ExtraAttacks();
	var checkEnemyDeath = AlliesAttack();
	if (checkEnemyDeath == true){
		DefeatEnemy();
		return;
	};
	//each additional source of dmg checks enemy death itself - dmg doesn't get passed here
	
	
	//5. Check if the enemy can attack (stuns etc); Attack
	if (EnemyIsStunned == false){
		var attack = WPICK(Enemy.attacks,Enemy.attackChances);
		var Pdmg = attack();
		if (Pdmg != "miss"){
			AlliesDefend(Pdmg);
			Pdmg += GetPdmgModifiers(); 
			var checkPlayerDeath = DamagePlayer(Pdmg);
			if (checkPlayerDeath == true) return;
		};
	};
	
	RoundTick();
	RefreshStatsPanel();
};

//Common Enemy Attacks
var CEA = {
	normal: function(){
		if (Player.eva+Player.ext_eva+RNG(Player.luck)+(RNG(2)-2) > Enemy.stats.acc+(RNG(2)-2)){
			//you aren't hit
			print("The "+Enemy.name+" misses you.<br>");
			return "miss";
		} else {
			//you are hit
			print(TEXT("The "+Enemy.name+" hits you.<br>","red"));
			return Enemy.stats.str;
		};
	}
};

var PdmgModifiers = [];

