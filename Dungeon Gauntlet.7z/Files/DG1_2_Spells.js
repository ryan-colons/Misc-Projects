//Spells
//Use types: 1 -not in combat; 2 -only in combat; 3 -only in shops

var LearnSpell = function(id){
	var spell = window[id];
	spell.level += 1;
};

var CastSpell = function(id){
	var spell = window[id];
	var Use = spell.use;
	if (spell.level < 1){
		window.alert("You do not know that spell");
		return;
	};
	if (Use==1 && InCombat() == true){
		window.alert("You cannot cast this spell while in combat.");
		return;
	};
	if (Use==2 && InCombat() == false){
		window.alert("This spell can be cast only in combat.");
		return;
	};
	if (Use==3 && R().type!="shop"){
		window.alert("This spell can be cast only in shops.");
		return;
	};
	
	if (Player.spellscast >= Player.mag + Player.ext_mag + Player.extracasts){
		window.alert("You cannot cast anymore spells right now.\nNote: the number of spells you can cast per combat is dependent on your magic level.");
		return;
	} else {
		var cost = spell.effect();
		if (cost != false) Player.spellscast += 1;
	};
	
	if (spell.takesTurn == true && spell.use == 2 && Enemy.stats.HP > 0) CombatRound();
};

//name, use, level, takesTurn, description, info, effect

var WhtMagic1 = {  //Heals	
	name: "Healing Light",
	use: 2,
	level: 0,
	takesTurn: true,
	description: "<br><strong>Healing Light</strong><br><br><em>Casts a healing light on you.</em><br><br>White magic<br>Restores HP<br>",
	info: "<br>Level One: Restore 1/6 max HP.<br>Level Two: Restore 1/3 max HP.<br>Level Three: Restore 1/2 max HP.",
	effect: function(){ 
		if (Player.HP >= Player.maxHP){
			window.alert("You need no healing.");
			return false;
		} else {
			print("You cast the spell. You feel much better.<br>");
			Player.HP += WhtMagic1.level/3 * 0.5 * Player.maxHP;
			//at level 1, restores 1/6 of maxHP
			//at level 2, restores 1/3 of maxHP
			//at level 3, restores 1/2 of maxHP
			if (Player.HP > Player.maxHP) Player.HP = Player.maxHP;
		};
	}
};
var WhtMagic2 = {  //Heals over time
	name: "Steady Restoration",
	use: 2,
	level: 0,
	takesTurn: false,
	description: "<br><strong>Steady Restoration</strong><br><br><em>A weak, but long-lasting healing spell.</em>\
				 <br><br>White magic<br>Restores some HP each round.<br>Quick cast",
	info: "<br>Level One: Lasts 3 rounds of combat.<br>Level Two: Lasts 4 rounds of combat.<br>Level Three: Lasts 5 rounds of combat.",
	effect: function(){
		print("You cast the spell, and a faint white glow surrounds you.<br>");
		AddRoundCounter("SteadyRestorationBuff", WhtMagic2.level+2);	
	}
};
var WhtMagic3 = {  //Hurts evil enemies
	name: "Light Ray",
	use: 2,
	level: 0,
	takesTurn: true,
	description: "<br><strong>Light Ray</strong><br><br><em>Casts a beam of light at an opponent.</em><br><br>White magic<br>Harms evil opponents.<br>",
	info: "<br>Level One: Deals a little damage to evil opponents.<br>Level Two: Deal more damage.<br>Level Three: Deal more damage and affects all\
			opponent types.",
	effect: function(){
		print("You cast a beam of light at the "+Enemy.name+".<br>");
		if (Enemy.type == "undead" || Enemy.type == "demon" || Enemy.type == "shadow" || WhtMagic3.level == 3){
			print("The "+Enemy.name+" burns in the light.<br>");
			DamageEnemy(WhtMagic3.level*3);
		} else print("The "+Enemy.name+" is not affected.<br>");	
	}
};
var WhtMagic4 = {  //Buff maxHP
	name: "White Aura",
	use: 2,
	level: 0,
	takesTurn: true,
	description: "<br><strong>White Aura</strong><br><br><em>Creates a protective aura around you.</em><br><br>White magic<br>Raises maxHP.<br>",
	info: "<br>Level One: Buff hitpoints.<br>Level Two: Increased power and duration.<br>Level Three: Greater power and duration.",
	effect: function(){
		print("You cast the spell, and a white aura surrounds you.<br>");
		WhiteAuraBuff.magnitude = WhtMagic4.level*(Player.mag+Player.ext_mag);
		AddRoundCounter("WhiteAuraBuff", WhtMagic4.level*4);
	}
};
var WhtMagic5 = {  //Massively buff armor for one turn 
	name: "Divine Protection",
	use: 2,
	level: 0,
	takesTurn: true,
	description: "<br><strong>Divine Protection</strong><br><br><em>Call for shelter from the divine.</em><br>\
				  <br>White magic<br>Protects you from damage<br>Lasts one turn",
	info: "<br>Level One: Blocks 10 damage.<br>Level Two: Blocks 20 damage<br>Level Three: Blocks 30 damage",
	effect: function(){
		DivineProtectionBuff.magnitude = WhtMagic5.level * 10;
		print("You call for protection.<br>");
		AddRoundCounter("DivineProtectionBuff",1);
	}
};

var BlkMagic1 = {  //Saps health
	name: "Life Drain",
	use: 2,
	level: 0,
	takesTurn: true,
	description: "<br><strong>Life Drain</strong><br><br><em>Drain energy from your opponent.</em><br><br><br>Black magic<br>Damages opponent<br>Restores HP",
	info: "<br>Level Two: Sap twice as much health.<br>Level Three: Sap three times as much health.",
	effect: function(){
		print("You drain life from the "+Enemy.name+".<br>");
		var dmg = (RNG(1)+2)*BlkMagic1.level;
		Player.HP += dmg;
		//HP gained from this doesn't get capped at maxHP
		DamageEnemy(dmg);
	}
};
var BlkMagic2 = {  //Debuff enemy
	name: "Curse",
	use: 2,
	level: 0,
	takesTurn: true,
	description: "<br><strong>Curse</strong><br><br><em>Afflict a curse on your opponent.</em><br><br>Black magic<br>Lowers opponent's stats.",
	info: "<br>Level One: Affects enemy strength.<br>Level Two: Also affect enemy accuracy.<br>Level Three: Also affects enemy evasiveness.",
	effect: function(){
		print("You curse the "+Enemy.name+".<br>");
		if (BlkMagic2.level > 0){ 
			CurseDebuff.str = BlkMagic2.level
			print(TEXT("The "+Enemy.name+" looks weaker.<br>","purple"));
		};
		if (BlkMagic2.level > 1){ 
			CurseDebuff.acc = BlkMagic2.level
			print(TEXT("The "+Enemy.name+" is stumbling slightly.<br>","purple"));
		};
		if (BlkMagic2.level > 2){
			CurseDebuff.eva = BlkMagic2.level
			print(TEXT("The "+Enemy.name+" is moving more slowly.<br>","purple"));
		};
		AddRoundCounter("CurseDebuff",Player.mag+Player.ext_mag+2);
	}
};
var BlkMagic3 = {  //Poisons enemy
	name: "Infect",
	use: 2,
	level: 0,
	takesTurn: true,
	description: "<br><strong>Infect</strong><br><br><em>Poison your opponent</em><br><br>Black magic<br>Damages opponent each turn.",
	info: "<br>Level One: Poisons opponent.<br>Level Two: Poison is 2x stronger.<br>Level Three: Poison is 3x stronger.",
	effect: function(){
		print("You cast the spell. The "+Enemy.name+" looks sick.<br>");
		Infection.magnitude = BlkMagic3.level*2;
		AddRoundCounter("Infection", Player.mag+Player.ext_mag+2);
	}
};
var BlkMagic4 = {  //Hurts enemy based on Player magic (magic*level)
	name: "Harm",
	use: 2,
	level: 0,
	takesTurn: true,
	description: "<br><strong>Harm</strong><br><br><em>A dark spell.</em><br><br>Black magic<br>Damages opponents.<br>Damage is based on your magic",
	info: "<br>Level One: Damages opponent.<br>Level Two: 2x damage.<br>Level Three: 3x damage.",
	effect: function(){
		print("You cast Harm. The "+Enemy.name+" is hurt.<br>");
		DamageEnemy( (Player.mag+Player.ext_mag) * BlkMagic4.level );
		//numbers might need to be fixed up
	}
};
var BlkMagic5 = {  //RNG(x) small attacks, each of which may miss or hit
	name: "Swarm",
	use: 2,
	level: 0,
	takesTurn: true,
	description: "<br><strong>Swarm</strong><br><br><em>A dark spell.</em><br><br>Black magic<br>Damages opponents<br>Swarm size is based on your magic",
	info: "<br>Level Two: swarm strength is doubled.<br>Level Three: swarm strength is tripled.",
	effect: function(){
		var dmg = 0;
		print("You conjure a swarm.<br>");
		for (n=0; n<Player.mag+Player.ext_mag; n++){
			if (RNG(1) == 0) print("&nbsp;The swarm misses the "+Enemy.name+".<br>");
			else {
				print("&nbsp;The swarm hits the "+Enemy.name+".<br>");
				dmg += BlkMagic5.level;
			};
		};
		DamageEnemy(dmg);
	}
};	

var BufMagic1 = {  //Buff strength
	name: "Strengthen",
	use: 2,
	level: 0,
	takesTurn: true, //maybe at level 3, these spells don't take a turn
	description: "<br><strong>Strengthen</strong><br><br><em>Applies extra magical force to your movements.</em><br><br>Increases strength",
	info: "<br>Level One: +1 str.<br>Level Two: +2 str.<br>Level Three: +3 str.",
	effect: function(){
		StrengthenBuff.magnitude = BufMagic1.level;
		print("You cast the spell. You feel stronger.<br>");
		AddRoundCounter("StrengthenBuff", Player.mag+Player.ext_mag+2);
	}
};
var BufMagic2 = {  //Buff accuracy
	name: "Focus",
	use: 2,
	level: 0,
	takesTurn: true, //maybe at level 3, these spells don't take a turn
	description: "<br><strong>Focus</strong><br><br><em>A spell to focus your mind and sharpen your vision.</em><br><br>Increases accuracy",
	info: "<br>Level One: +1 acc.<br>Level Two: +2 acc.<br>Level Three: +3 acc.",
	effect: function(){
		FocusBuff.magnitude = BufMagic2.level;
		print("You cast the spell. You focus in on your opponent.<br>");
		AddRoundCounter("FocusBuff", Player.mag+Player.ext_mag+RNG(2));
	}
};
var BufMagic3 = {  //Buff evasiveness
	name: "Quicken",
	use: 2,
	level: 0,
	takesTurn: true, //maybe at level 3, these spells don't take a turn
	description: "<br><strong>Quicken</strong><br><br><em>A spell to make your movements more nimble.</em><br><br>Increases evasiveness",
	info: "<br>Level One: +1 eva.<br>Level Two: +2 eva.<br>Level Three: +3 eva.",
	effect: function(){
		QuickenBuff.magnitude = BufMagic3.level;
		print("You cast the spell. You feel more agile.<br>");
		AddRoundCounter("QuickenBuff", Player.mag+Player.ext_mag+RNG(2));
	}
};
var BufMagic4 = {  //Buff luck
	name: "Fortune",
	use: 2,
	level: 0,
	takesTurn: true, //maybe at level 3, these spells don't take a turn
	description: "<br><strong>Fortune</strong><br><br><em>A spell to make things work more in your favour.</em><br><br>Increases luck",
	info: "<br>Level One: +1 luck.<br>Level Two: +2 luck.<br>Level Three: +3 luck.",
	effect: function(){
		FortuneBuff.magnitude = BufMagic4.level;
		print("You cast the spell. You feel good.<br>");
		AddRoundCounter("FortuneBuff", Player.mag+Player.ext_mag+RNG(2));
	}
};
var BufMagic5 = {  //buff armor
	name: "Fortify",
	use: 2,
	level: 0,
	takesTurn: true, //maybe at level 3, these spells don't take a turn
	description: "<br><strong>Fortify</strong><br><br><em>A protection spell.</em><br><br>Increases armor",
	info: "<br>Level One: +1 armor.<br>Level Two: +2 armor.<br>Level Three: +3 armor.",
	effect: function(){
		FortifyBuff.magnitude = BufMagic5.level;
		print("You cast the spell. Your skin thickens.<br>");
		AddRoundCounter("FortifyBuff", Player.mag+Player.ext_mag+RNG(2));
	}
};

var SumMagic1 = { /*summon attacking ally*/ 
	name: "Summon Astral Warrior",
	use: 2,
	level: 0,
	takesTurn: true,
	description: "<br><strong>Summon Astral Warrior</strong><br><br><em>Summon an astral warrior to fight with you.</em>\
				  <br><br>Warrior's power is based on your magic",
	info: "<br>Level One: Summon persists 3 rounds.<br>Level Two: Summon persists 6.<br>Level Three: Summon persists 9 rounds.",
	effect: function(){
		if (SummonedAlly.ally == 0){
			ActiveAllies.push("AstralWarrior");
			SummonedAlly.ally = "AstralWarrior";
			AstralWarrior.str = Player.mag+Player.ext_mag;
			AstralWarrior.acc = (Player.mag+Player.ext_mag)*1.5;
			AddRoundCounter("SummonedAlly", SumMagic1.level*3);
		} else {
			print("You already have a summoned ally.<br>");
			return false;
		};
	}
};
var SumMagic2 = { /*summon defending ally*/ 
	name: "Summon Astral Guardian",
	use: 2,
	level: 0,
	takesTurn: true,
	description: "<br><strong>Summon Astral Warrior</strong><br><br><em>Summon an astral guardian to defend you.</em>\
				  <br><br>Guardian's power is based on your magic",
	info: "<br>Level One: Summon persists 3 rounds.<br>Level Two: Summon persists 6.<br>Level Three: Summon persists 9 rounds.",
	effect: function(){
		if (SummonedAlly.ally == 0){
			ActiveAllies.push("AstralGuardian");
			SummonedAlly.ally = "AstralGuardian";
			AstralGuardian.HP = (Player.mag+Player.ext_mag)*2;
			AstralGuardian.ShieldSize = Player.mag+Player.ext_mag;
			AddRoundCounter("SummonedAlly", SumMagic2.level*3);
		} else {
			print("You already have a summoned ally.<br>");
			return false;
		};
	}
};
var SumMagic3 = { /*summon support ally*/ };
var SumMagic4 = { /*banish enemies*/ 
	name: "Banish",
	use: 2,
	level: 0,
	takesTurn: true,
	description: "<br><strong>Banish</strong><br><br><em>Banish your opponents to another world.</em>\
				  <br><br>Summoning Magic<br>Tricky to cast",
	info: "<br>Level One: Banish opponent.<br>Level Two: Spell is easier to cast.<br>Level Three: Spell is much easier to cast.",
	effect: function(){
		var BanishNo = (Player.mag + Player.ext_mag) * SumMagic4.level;
		if (RNG(BanishNo) > Enemy.stats.eva+Enemy.stats.HP){
			print("You banish the "+Enemy.name+".<br>");
			R().cleared = true;
			RoomsCleared += 1; //should RoomsCleared be increased?
			//AlliesGain();	   //no AlliesGain()
			Player.HP = Player.maxHP;
			//EnemyItemDrop(); //no item drops
			RoomTick();
			RefreshStatsPanel();
		} else {
			print("You failed to cast the spell.");
		};
	}
};
var SumMagic5 = { /*conjure stuff in combat (e.g. barriers) and out of combat (e.g. equipment)*/ };

var TraMagic1 = { /*Enchant equipment with gems.*/ 
	name: "Enchant",
	use: 1,
	level: 0,
	takesTurn: false,
	description: "<br><strong>Enchant</strong><br><br><em>Use gems to enchant equipment.</em><br><br>Transmutation magic",
	info: "<br>Level Two: Gem values are doubled.<br>Level Three: Gem values are tripled",
	effect: function(){
		OpenExtraMenu();
		$("#extramenu").append("Choose a gem and a piece of equipment.<br>");
		$("#extramenu").append("<div id='gemselection'>Gems:<br><br></div>");
		$("#extramenu").append("<div id='equipmentselection'>Equipment:<br><br></div>");
		$("#extramenu").append("<br><div id='leaveEnchanting'><br>Done</div>");
		$("#extramenu").append("<div id='executeEnchanting'><br>Enchant</div>");
		for (i=0; i<Inventory.misc.length; i++){
			var item = window[Inventory.misc[i]];
			if (item.type == "gem") $("#gemselection").append("<div class='gemchoice' id='"+Inventory.misc[i]+"'>"+item.name+"</div>");
		};
		for (i=0; i<Inventory.equipment.length; i++){
			var item = window[Inventory.equipment[i]];
			if (item.enchantable == true) $("#equipmentselection").append("<div class='equipmentchoice' id='"+Inventory.equipment[i]+"'>"+item.name+"</div>");
		};
		$(".gemchoice, .equipmentchoice").hover(function(){
			$(this).css('border-color','white');
		}, function(){
			$(this).css('border-color','black');
		});
		$(".gemchoice").click(function(){
			$(".gemchoice").css('background-color','white');
			$(this).css('background-color','red');
			TraMagic1.chosenGem = this.id;
		});
		$(".equipmentchoice").click(function(){
			$(".equipmentchoice").css('background-color','white');
			$(this).css('background-color','red');
			TraMagic1.chosenEquipment = this.id;
		});
		$("#leaveEnchanting").click(function(){
			CloseExtraMenu();
			TraMagic1.chosenGem = 0;
			TraMagic1.chosenEquipment = 0;
			TraMagic2.gem1 == 0;
			TraMagic2.gem2 == 0;
		});
		$("#executeEnchanting").click(function(){
			if (TraMagic1.chosenGem == 0) window.alert("You must select a gem to enchant with.");
			else if (TraMagic1.chosenEquipment == 0) window.alert("You must select a piece of equipment to enchant.");
			else { 
				Enchant();
				CloseExtraMenu();
			};
		});
	},
	chosenGem: 0,
	chosenEquipment: 0
};
var TraMagic2 = { /*Transmute gems together.*/ 
	name: "Alchemy",
	use: 1,
	level: 0,
	takesTurn: false,
	description: "<br><strong>Alchemy</strong><br><br><em>The magic art of transmuting substances.</em><br><br>Transmutation Magic<br>Combine gems",
	info: "<br>Level Two: Gem values are doubled.<br>Level Three: Gem values are tripled",
	effect: function(){
		OpenExtraMenu();
		$("#extramenu").empty();
		$("#extramenu").append("Alchemy<br>");
		$("#extramenu").append("<div class='gemselection' id='selectgem'>Choose a gem to transmute:<br><br></div>");
		$("#extramenu").append("<div class='gemselection' id='alchemyproduct'>New Gem:<br><br></div>");
		$("#extramenu").append("<br><div id='leaveEnchanting'><br>Finish</div>");
		$("#extramenu").append("<div id='executeAlchemy'><br>Select</div>");
		for (i=0; i<Inventory.misc.length; i++){
			var item = window[Inventory.misc[i]];
			if (item.type == "gem"){
				$("#selectgem").append("<div class='alchemychoice' id='"+Inventory.misc[i]+"'>"+item.name+"</div>");
			}
		};
		$(".alchemychoice").hover(function(){
			$(this).css('border-color','white');
		}, function(){
			$(this).css('border-color','black');
		});
		$(".alchemychoice").click(function(){
			$(".alchemychoice").css('background-color','white');
			$(this).css('background-color','red');
			TraMagic2.chosenGem = this.id;
		});
		$("#executeAlchemy").click(function(){
			if (TraMagic2.chosenGem == 0) window.alert("You must select a gem.");
			else Alchemy();
		});
		$("#leaveEnchanting").click(function(){
			if (TraMagic2.crystal.nothing == false){	
				print("You create a new gem.");
				window["UniqueGem"+UniqueItemsNo] = new Object();
				n = window["UniqueGem"+UniqueItemsNo];
				//name, type, stats, value, description
				n.name = TraMagic2.crystal.name;
				n.type = "gem";
				n.value = 2;
				n.description = TraMagic2.crystal.description;
				n.stats = {};
				n.stats.armor = TraMagic2.crystal.armor;
				n.stats.str = TraMagic2.crystal.str;
				n.stats.mag = TraMagic2.crystal.mag;
				n.stats.acc = TraMagic2.crystal.acc;
				n.stats.eva = TraMagic2.crystal.eva;
				n.stats.luck = TraMagic2.crystal.luck;
				Inventory.misc.push("UniqueGem"+UniqueItemsNo);
			};
			TraMagic2.crystal = { armor: 0, str: 0, mag: 0, acc: 0, eva: 0, luck: 0, nothing: true };
			TraMagic2.chosenGem = 0;
			CloseExtraMenu();
			RefreshInventoryMenu();
		});
	},
	chosenGem: 0,
	crystal: { armor: 0, str: 0, mag: 0, acc: 0, eva: 0, luck: 0, nothing: true }
};
var TraMagic3 = { /*Turn items into points*/ 
	name: "Dissolution",
	use: 1,
	level: 0,
	takesTurn: false,
	description: "<br><strong>Dissolution</strong><br><br><em>Extract the intrinsic value of various items.</em><br>\
				  <br>Transmutation Magic<br>Turn items into points",
	info: "<br>Level Two: Values are doubled.<br>Level Three: Values are tripled",
	effect: function(){
		OpenExtraMenu();
		$("#extramenu").empty();
		$("#extramenu").append("Dissolution<br>");
		$("#extramenu").append("<div id='itemselection'>Choose an item to dissolve:<br><br></div>");
		$("#extramenu").append("<br><div id='leaveDissolution'><br>Cancel</div>");
		$("#extramenu").append("<div id='executeDissolution'><br>Dissolve</div>");
		for (i=0; i<Inventory.misc.length; i++){
			$("#itemselection").append("<div class='itemchoice' id='"+Inventory.misc[i]+"'>"+window[Inventory.misc[i]].name+"</div>");
		};
		for (i=0; i<Inventory.items.length; i++){
			$("#itemselection").append("<div class='itemchoice' id='"+Inventory.items[i]+"'>"+window[Inventory.items[i]].name+"</div>");
		};
		for (i=0; i<Inventory.equipment.length; i++){
			$("#itemselection").append("<div class='itemchoice' id='"+Inventory.equipment[i]+"'>"+window[Inventory.equipment[i]].name+"</div>");
		};
		$(".itemchoice").hover(function(){
			$(this).css('border-color','white');
		}, function(){
			$(this).css('border-color','black');
		});
		$(".itemchoice").click(function(){
			$(".itemchoice").css('background-color','white');
			$(this).css('background-color','red');
			TraMagic3.chosenItem = this.id;
		});
		$("#executeDissolution").click(function(){
			if (TraMagic3.chosenItem == 0) window.alert("You must select an item.");
			else {
				var item = window[TraMagic3.chosenItem];
				print("You dissolve the "+item.name+". You gain "+item.value+" points.<br>");
				PointGain(item.value*TraMagic3.level);
				if (item.type == "usable") Inventory.items.splice(Inventory.items.indexOf(item), 1);
				else if (item.type == "equipment") Inventory.equipment.splice(Inventory.equipment.indexOf(item), 1);
				else Inventory.misc.splice(Inventory.misc.indexOf(item), 1);
				CloseExtraMenu();
				RefreshInventoryMenu();
				TraMagic3.chosenItem = 0;
			};
		});
		$("#leaveDissolution").click(function(){
			CloseExtraMenu();
			RefreshInventoryMenu();
		});
	},
	chosenItem: 0
};
var TraMagic4 = { /*Change enemy into a different enemy*/ 
	//name, use, level, takesTurn, description, info, effect
	name: "Transform",
	use: 2,
	level: 0,
	takesTurn: true,
	description: "<br><strong>Transform</strong><br><br><em>Transform monsters into other monsters.</em><br><br>Transmutation Magic<br>",
	info: "<br>Level Two: May tranform into special monsters<br>Level Three: Often transforms into special monsters",
};
var TraMagic5 = { /*Change own race OR Change room states*/ };




